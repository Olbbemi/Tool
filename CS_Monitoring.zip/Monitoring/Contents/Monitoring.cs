﻿using System;
using System.Timers;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Windows.Forms.DataVisualization.Charting;

using Network;

namespace Monitoring
{
    public partial class C_Monitor : Form
    {
        C_Network m_network;

        System.Drawing.SolidBrush m_GUI_brush;
        System.Drawing.Graphics m_GUI_graphic;

        private Rectangle m_chatting_rectangle, m_matching_rectangle, m_battle_rectangle;
        private Font m_GUI_head_font, m_GUI_on_body_font, m_GUI_off_body_font, m_GUI_subbody_font, m_dialog_title_font;

        private Point m_chatting_head_point, m_chatting_on_body_point, m_chatting_off_body_point, m_chatting_connect_point, m_chatting_disconnect_point
                    , m_matching_head_point, m_matching_on_body_point, m_matching_off_body_point, m_matching_connect_point, m_matching_disconnect_point
                    , m_battle_head_point, m_battle_on_body_point, m_battle_off_body_point,       m_battle_connect_point, m_battle_disconnect_point;

        private Size m_chatting_head_size, m_chatting_on_body_size, m_chatting_off_body_size, m_chatting_connect_size, m_chatting_disconnect_size
                   , m_matching_head_size, m_matching_on_body_size, m_matching_off_body_size, m_matching_connect_size, m_matching_disconnect_size
                   , m_battle_head_size, m_battle_on_body_size, m_battle_off_body_size,       m_battle_connect_size, m_battle_disconnect_size;

        private Label m_chatting_head, m_chatting_body, m_chatting_subbody
                    , m_matching_head, m_matching_body, m_matching_connect, m_matching_disconnect
                    , m_battle_head, m_battle_body, m_battle_connect, m_battle_disconnect;

        private Label[] customLabels;

        private ElementPosition m_dialog_title_position, m_dialog_chatarea_position, m_recv_dialog_legend_position, m_send_dialog_legend_position;
                                
        private Legend m_processor_recv_legend, m_processor_send_legend;
              
        public bool m_matching_power_flag, m_battle_power_flag,
                    m_processor_cpu_flag, m_processor_memory_flag, m_processor_network_flag, m_processor_nonpage_flag,
                    m_chatting_power_flag, m_chatting_cpu_flag, m_chatting_memory_flag, m_chatting_packet_flag, m_chatting_session_flag, m_chatting_login_flag, m_chatting_room_flag;
        
        public List<Int32> m_processor_cpu_queue, m_processor_memory_queue, m_processor_recv_queue, m_processor_send_queue, m_processor_nonpage_queue,
                             m_chatting_cpu_queue, m_chatting_memory_queue, m_chatting_packet_queue, m_chatting_session_queue, m_chatting_login_queue, m_chatting_room_queue;

        public Int32 m_processor_cpu_count, m_processor_memory_count, m_processor_recv_count, m_processor_send_count, m_processor_nonpage_count,
                     m_chatting_power_count, m_chatting_cpu_count, m_chatting_memory_count, m_chatting_packet_count, m_chatting_session_count, m_chatting_login_count, m_chatting_room_count;

        public Int16 m_process_cpu_accum, m_process_memory_accum, m_process_send_accum, m_process_recv_accum, m_process_nonpage_accum,
                     m_chatting_cpu_accum, m_chatting_memory_accum, m_chatting_packet_accum, m_chatting_session_accum, m_chatting_login_accum, m_chatting_room_accum;

        public object m_process_cpu_lock, m_process_memory_lock, m_process_send_lock, m_process_recv_lock, m_process_nonpage_lock,
                      m_chatting_cpu_lock, m_chatting_memory_lock, m_chatting_packet_lock, m_chatting_session_lock, m_chatting_login_lock, m_chatting_room_lock;

        public C_Monitor()
        {
            InitializeComponent();
            m_network = new C_Network(this);
            
            // rectangle 초기화
            m_chatting_rectangle = new Rectangle(5, 10, 100, 150);
            m_matching_rectangle = new Rectangle(5, 170, 100, 150);
            m_battle_rectangle   = new Rectangle(5, 330, 100, 150);

            // brush 초기화
            m_GUI_brush = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(50, 50, 50));

            // label 초기화
            m_chatting_head = new Label();  m_chatting_body = new Label(); m_chatting_subbody = new Label();
            m_matching_head = new Label();  m_matching_body = new Label(); m_matching_connect = new Label(); m_matching_disconnect = new Label();
            m_battle_head = new Label();    m_battle_body = new Label();   m_battle_connect = new Label();   m_battle_disconnect = new Label();
            
            customLabels = new Label[5];

            // point 초기화
            m_chatting_head_point = new System.Drawing.Point(5, 10);     m_chatting_off_body_point = new System.Drawing.Point(5, 80);   m_chatting_on_body_point = new System.Drawing.Point(10, 80);
            m_chatting_connect_point = new System.Drawing.Point(28, 45); m_chatting_disconnect_point = new System.Drawing.Point(21, 45);

            m_matching_head_point = new System.Drawing.Point(5, 170);     m_matching_off_body_point = new System.Drawing.Point(5, 240);   m_matching_on_body_point = new System.Drawing.Point(10, 240);
            m_matching_connect_point = new System.Drawing.Point(28, 205); m_matching_disconnect_point = new System.Drawing.Point(21, 205);
        
            m_battle_head_point = new System.Drawing.Point(5, 330);       m_battle_off_body_point = new System.Drawing.Point(5, 400);     m_battle_on_body_point = new System.Drawing.Point(10, 400);
            m_battle_connect_point = new System.Drawing.Point(28, 365);   m_battle_disconnect_point = new System.Drawing.Point(21, 365);

            // size 초기화
            m_chatting_head_size = new System.Drawing.Size(100, 20);    m_chatting_off_body_size = new System.Drawing.Size(100, 40);     m_chatting_on_body_size = new System.Drawing.Size(90, 50);
            m_chatting_connect_size = new System.Drawing.Size(60, 15);  m_chatting_disconnect_size = new System.Drawing.Size(70, 15);

            m_matching_head_size = new System.Drawing.Size(100, 20);    m_matching_off_body_size = new System.Drawing.Size(100, 40);     m_matching_on_body_size = new System.Drawing.Size(90, 50);
            m_matching_connect_size = new System.Drawing.Size(60, 15);  m_matching_disconnect_size = new System.Drawing.Size(70, 15);

            m_battle_head_size = new System.Drawing.Size(100, 20);      m_battle_off_body_size = new System.Drawing.Size(100, 40);       m_battle_on_body_size = new System.Drawing.Size(90, 50);
            m_battle_connect_size = new System.Drawing.Size(60, 15);    m_battle_disconnect_size = new System.Drawing.Size(70, 15);

            // font 초기화
            m_GUI_head_font = new Font("맑은고딕", 12, FontStyle.Bold);
            m_GUI_off_body_font = new Font("맑은고딕", 28, FontStyle.Bold);
            m_GUI_on_body_font = new Font("맑은고딕", 32, FontStyle.Bold);
            m_GUI_subbody_font = new Font("맑은고딕", 8, FontStyle.Bold);
            m_dialog_title_font = new Font("맑은고딕", 9, FontStyle.Bold);

            // legend(범례) 초기화          
            m_processor_recv_legend = new Legend("Processor_Recv_Legend");
            m_processor_send_legend = new Legend("Processor_Send_Legend");       

            // position 초기화
            m_dialog_title_position = new ElementPosition(0, 0, 150, 13.5f);
            m_dialog_chatarea_position = new ElementPosition(0, 15, 80, 85);
            m_recv_dialog_legend_position = new ElementPosition(87, 15, 15, 10);
            m_send_dialog_legend_position = new ElementPosition(85, 25, 20, 10);
        
            // 컨텐츠 초기화
            {
                m_processor_cpu_flag = true;   m_processor_memory_flag = true;  m_processor_network_flag = true; m_processor_nonpage_flag = true;
                m_chatting_power_flag = false; m_chatting_cpu_flag = true;      m_chatting_memory_flag = true;   m_chatting_packet_flag = true;  m_chatting_session_flag = true;  m_chatting_login_flag = true; m_chatting_room_flag = true;

                m_matching_power_flag = false;
                m_battle_power_flag = false;

                m_process_cpu_accum = 0; m_process_memory_accum = 0; m_process_send_accum = 0; m_process_recv_accum = 0; m_process_nonpage_accum = 0;
                m_chatting_cpu_accum = 0; m_chatting_memory_accum = 0; m_chatting_packet_accum = 0; m_chatting_session_accum = 0; m_chatting_login_accum = 0; m_chatting_room_accum = 0;

                m_processor_cpu_count = 0; m_processor_memory_count = 0; m_processor_recv_count = 0; m_processor_send_count = 0; m_processor_nonpage_count = 0;
                m_chatting_power_count = 0; m_chatting_cpu_count = 0; m_chatting_memory_count = 0; m_chatting_packet_count = 0; m_chatting_session_count = 0; m_chatting_login_count = 0; m_chatting_room_count = 0;
            }

            // 락 초기화
            {
                m_process_cpu_lock = new object();  m_process_memory_lock = new object();   m_process_send_lock = new object();
                m_process_recv_lock = new object(); m_process_nonpage_lock = new object();

                m_chatting_cpu_lock = new object(); m_chatting_memory_lock = new object(); m_chatting_packet_lock = new object();
                m_chatting_session_lock = new object(); m_chatting_login_lock = new object(); m_chatting_room_lock = new object();
            }

            /*
             * --------------------
             * 각 다이얼로그 초기화
             * --------------------
             */

            // 프로세서 CPU 다이얼로그 초기화
            {
                m_processor_cpu_queue = new List<Int32>();

                Processor_CPU.Titles.Clear(); Processor_CPU.ChartAreas.Clear();
                Processor_CPU.Legends.Clear(); Processor_CPU.Series.Clear();

                Processor_CPU.BackColor = Color.FromArgb(70, 70, 70);

                Processor_CPU.Titles.Add("Processor CPU");
                Processor_CPU.Titles[0].BackColor = Color.DimGray;
                Processor_CPU.Titles[0].Font = m_dialog_title_font;
                Processor_CPU.Titles[0].Position = m_dialog_title_position;
                Processor_CPU.Titles[0].Alignment = ContentAlignment.TopLeft;

                Processor_CPU.ChartAreas.Add("processor_cpu");
                Processor_CPU.ChartAreas["processor_cpu"].BackColor = Color.FromArgb(70, 70, 70);
                Processor_CPU.ChartAreas["processor_cpu"].Position = m_dialog_chatarea_position;
                Processor_CPU.ChartAreas["processor_cpu"].AxisY.MajorGrid.LineColor = Color.Black;
                Processor_CPU.ChartAreas["processor_cpu"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Processor_CPU.ChartAreas["processor_cpu"].AxisY.Maximum = 100;
                Processor_CPU.ChartAreas["processor_cpu"].AxisX.Enabled = AxisEnabled.False;
             
                Processor_CPU.Series.Add("cpu_series");
                Processor_CPU.Series[0].ChartType = SeriesChartType.Line;
                Processor_CPU.Series[0].Color = Color.GhostWhite;
            }

            // 프로세서 Memory 다이얼로그 초기화
            {
                m_processor_memory_queue = new List<Int32>();

                Processor_Memory.Titles.Clear(); Processor_Memory.ChartAreas.Clear();
                Processor_Memory.Legends.Clear(); Processor_Memory.Series.Clear();

                Processor_Memory.BackColor = Color.FromArgb(70, 70, 70);

                Processor_Memory.Titles.Add("Processor Memory");
                Processor_Memory.Titles[0].BackColor = Color.DimGray;
                Processor_Memory.Titles[0].Font = m_dialog_title_font;
                Processor_Memory.Titles[0].Position = m_dialog_title_position;
                Processor_Memory.Titles[0].Alignment = ContentAlignment.TopLeft;

                Processor_Memory.ChartAreas.Add("processor_memory");
                Processor_Memory.ChartAreas["processor_memory"].BackColor = Color.FromArgb(70, 70, 70);
                Processor_Memory.ChartAreas["processor_memory"].Position = m_dialog_chatarea_position;
                Processor_Memory.ChartAreas["processor_memory"].AxisY.MajorGrid.LineColor = Color.Black;
                Processor_Memory.ChartAreas["processor_memory"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Processor_Memory.ChartAreas["processor_memory"].AxisX.Enabled = AxisEnabled.False;

                Processor_Memory.Series.Add("memory_series");
                Processor_Memory.Series[0].ChartType = SeriesChartType.Line;
                Processor_Memory.Series[0].Color = Color.GhostWhite;
            }

            // 프로세서 Network 다이얼로그 초기화
            {
                m_processor_recv_queue = new List<Int32>();
                m_processor_send_queue = new List<Int32>();

                Processor_Network.Titles.Clear(); Processor_Network.ChartAreas.Clear();
                Processor_Network.Legends.Clear(); Processor_Network.Series.Clear();

                Processor_Network.BackColor = Color.FromArgb(70, 70, 70);

                Processor_Network.Titles.Add("Processor Network");
                Processor_Network.Titles[0].BackColor = Color.DimGray;
                Processor_Network.Titles[0].Font = m_dialog_title_font;
                Processor_Network.Titles[0].Position = m_dialog_title_position;
                Processor_Network.Titles[0].Alignment = ContentAlignment.TopLeft;

                Processor_Network.ChartAreas.Add("processor_network");
                Processor_Network.ChartAreas["processor_network"].BackColor = Color.FromArgb(70, 70, 70);
                Processor_Network.ChartAreas["processor_network"].Position = m_dialog_chatarea_position;
                Processor_Network.ChartAreas["processor_network"].AxisY.MajorGrid.LineColor = Color.Black;
                Processor_Network.ChartAreas["processor_network"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Processor_Network.ChartAreas["processor_network"].AxisX.Enabled = AxisEnabled.False;

                m_processor_send_legend.Position = m_send_dialog_legend_position;
                m_processor_send_legend.BackColor = Color.FromArgb(70, 70, 70);
                m_processor_send_legend.ForeColor = Color.White;
                Processor_Network.Legends.Add(m_processor_send_legend);

                m_processor_recv_legend.Position = m_recv_dialog_legend_position;
                m_processor_recv_legend.BackColor = Color.FromArgb(70, 70, 70);
                m_processor_recv_legend.ForeColor = Color.White;
                Processor_Network.Legends.Add(m_processor_recv_legend);
                
                Processor_Network.Series.Add("recv_series");
                Processor_Network.Series[0].ChartType = SeriesChartType.Line;
                Processor_Network.Series[0].Color = Color.GhostWhite;
                Processor_Network.Series[0].Legend = "Processor_Recv_Legend";
                Processor_Network.Series[0].LegendText = "recv";
                Processor_Network.Series["recv_series"].IsVisibleInLegend = true;

                Processor_Network.Series.Add("send_series");
                Processor_Network.Series[1].ChartType = SeriesChartType.Line;
                Processor_Network.Series[1].Color = Color.DarkBlue;
                Processor_Network.Series[1].Legend = "Processor_Send_Legend";
                Processor_Network.Series[1].LegendText = "send";
            }

            // 프로세서 Nonpage 다이얼로그 초기화
            {
                m_processor_nonpage_queue = new List<Int32>();

                Processor_Nonpage.Titles.Clear(); Processor_Nonpage.ChartAreas.Clear();
                Processor_Nonpage.Legends.Clear(); Processor_Nonpage.Series.Clear();

                Processor_Nonpage.BackColor = Color.FromArgb(70, 70, 70);

                Processor_Nonpage.Titles.Add("Processor Nonpage");
                Processor_Nonpage.Titles[0].BackColor = Color.DimGray;
                Processor_Nonpage.Titles[0].Font = m_dialog_title_font;
                Processor_Nonpage.Titles[0].Position = m_dialog_title_position;
                Processor_Nonpage.Titles[0].Alignment = ContentAlignment.TopLeft;

                Processor_Nonpage.ChartAreas.Add("processor_nonpage");
                Processor_Nonpage.ChartAreas["processor_nonpage"].BackColor = Color.FromArgb(70, 70, 70);
                Processor_Nonpage.ChartAreas["processor_nonpage"].Position = m_dialog_chatarea_position;
                Processor_Nonpage.ChartAreas["processor_nonpage"].AxisY.MajorGrid.LineColor = Color.Black;
                Processor_Nonpage.ChartAreas["processor_nonpage"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Processor_Nonpage.ChartAreas["processor_nonpage"].AxisX.Enabled = AxisEnabled.False;
           
                Processor_Nonpage.Series.Add("nonpage_series");
                Processor_Nonpage.Series[0].ChartType = SeriesChartType.Line;
                Processor_Nonpage.Series[0].Color = Color.GhostWhite;
            }

            // 채팅 CPU 다이얼로그 초기화
            {
                m_chatting_cpu_count = 0;
                m_chatting_cpu_queue = new List<Int32>();

                Chatting_CPU.Titles.Clear();  Chatting_CPU.ChartAreas.Clear();
                Chatting_CPU.Legends.Clear(); Chatting_CPU.Series.Clear();
               
                Chatting_CPU.BackColor = Color.FromArgb(70, 70, 70);

                Chatting_CPU.Titles.Add("Chatting CPU");
                Chatting_CPU.Titles[0].BackColor = Color.DimGray;
                Chatting_CPU.Titles[0].Font = m_dialog_title_font;
                Chatting_CPU.Titles[0].Position = m_dialog_title_position;
                Chatting_CPU.Titles[0].Alignment = ContentAlignment.TopLeft;

                Chatting_CPU.ChartAreas.Add("chatting_cpu");
                Chatting_CPU.ChartAreas["chatting_cpu"].BackColor = Color.FromArgb(70, 70, 70);
                Chatting_CPU.ChartAreas["chatting_cpu"].Position = m_dialog_chatarea_position;
                Chatting_CPU.ChartAreas["chatting_cpu"].AxisY.MajorGrid.LineColor = Color.Black;
                Chatting_CPU.ChartAreas["chatting_cpu"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Chatting_CPU.ChartAreas["chatting_cpu"].AxisY.Maximum = 100;
                Chatting_CPU.ChartAreas["chatting_cpu"].AxisX.Enabled = AxisEnabled.False;

                Chatting_CPU.Series.Add("cpu_series");
                Chatting_CPU.Series[0].ChartType = SeriesChartType.Line;
                Chatting_CPU.Series[0].Color = Color.WhiteSmoke;
             
            }

            // 채팅 Memory 다이얼로그 초기화
            {
                m_chatting_memory_count = 0;
                m_chatting_memory_queue = new List<Int32>();

                Chatting_Memory.Titles.Clear();  Chatting_Memory.ChartAreas.Clear();
                Chatting_Memory.Legends.Clear(); Chatting_Memory.Series.Clear();

                Chatting_Memory.BackColor = Color.FromArgb(70, 70, 70);

                Chatting_Memory.Titles.Add("Chatting Memory");
                Chatting_Memory.Titles[0].BackColor = Color.DimGray;
                Chatting_Memory.Titles[0].Font = m_dialog_title_font;
                Chatting_Memory.Titles[0].Position = m_dialog_title_position;
                Chatting_Memory.Titles[0].Alignment = ContentAlignment.TopLeft;
               
                Chatting_Memory.ChartAreas.Add("chatting_memory");
                Chatting_Memory.ChartAreas["chatting_memory"].BackColor = Color.FromArgb(70, 70, 70);
                Chatting_Memory.ChartAreas["chatting_memory"].Position = m_dialog_chatarea_position;
                Chatting_Memory.ChartAreas["chatting_memory"].AxisY.MajorGrid.LineColor = Color.Black;
                Chatting_Memory.ChartAreas["chatting_memory"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Chatting_Memory.ChartAreas["chatting_memory"].AxisX.Enabled = AxisEnabled.False;

                Chatting_Memory.Series.Add("memory_series");
                Chatting_Memory.Series[0].ChartType = SeriesChartType.Line;
                Chatting_Memory.Series[0].Color = Color.WhiteSmoke;

            }

            // 채팅 PacketPool 다이얼로그 초기화
            {
                m_chatting_packet_count = 0;
                m_chatting_packet_queue = new List<Int32>();

                Chatting_Packet.Titles.Clear(); Chatting_Packet.ChartAreas.Clear();
                Chatting_Packet.Legends.Clear(); Chatting_Packet.Series.Clear();

                Chatting_Packet.BackColor = Color.FromArgb(70, 70, 70);

                Chatting_Packet.Titles.Add("Chatting Packet Pool");
                Chatting_Packet.Titles[0].BackColor = Color.DimGray;
                Chatting_Packet.Titles[0].Font = m_dialog_title_font;
                Chatting_Packet.Titles[0].Position = m_dialog_title_position;
                Chatting_Packet.Titles[0].Alignment = ContentAlignment.TopLeft;

                Chatting_Packet.ChartAreas.Add("chatting_packet");
                Chatting_Packet.ChartAreas["chatting_packet"].BackColor = Color.FromArgb(70, 70, 70);
                Chatting_Packet.ChartAreas["chatting_packet"].Position = m_dialog_chatarea_position;
                Chatting_Packet.ChartAreas["chatting_packet"].AxisY.MajorGrid.LineColor = Color.Black;
                Chatting_Packet.ChartAreas["chatting_packet"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Chatting_Packet.ChartAreas["chatting_packet"].AxisX.Enabled = AxisEnabled.False;

                Chatting_Packet.Series.Add("packet_series");
                Chatting_Packet.Series[0].ChartType = SeriesChartType.Line;
                Chatting_Packet.Series[0].Color = Color.WhiteSmoke;
            }

            // 채팅 Session 다이얼로그 초기화
            {
                m_chatting_session_count = 0;
                m_chatting_session_queue = new List<Int32>();

                Chatting_Session.Titles.Clear(); Chatting_Session.ChartAreas.Clear();
                Chatting_Session.Legends.Clear(); Chatting_Session.Series.Clear();

                Chatting_Session.BackColor = Color.FromArgb(70, 70, 70);

                Chatting_Session.Titles.Add("Chatting Session");
                Chatting_Session.Titles[0].BackColor = Color.DimGray;
                Chatting_Session.Titles[0].Font = m_dialog_title_font;
                Chatting_Session.Titles[0].Position = m_dialog_title_position;
                Chatting_Session.Titles[0].Alignment = ContentAlignment.TopLeft;

                Chatting_Session.ChartAreas.Add("chatting_session");
                Chatting_Session.ChartAreas["chatting_session"].BackColor = Color.FromArgb(70, 70, 70);
                Chatting_Session.ChartAreas["chatting_session"].Position = m_dialog_chatarea_position;
                Chatting_Session.ChartAreas["chatting_session"].AxisY.MajorGrid.LineColor = Color.Black;
                Chatting_Session.ChartAreas["chatting_session"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Chatting_Session.ChartAreas["chatting_session"].AxisX.Enabled = AxisEnabled.False;

                Chatting_Session.Series.Add("session_series");
                Chatting_Session.Series[0].ChartType = SeriesChartType.Line;
                Chatting_Session.Series[0].Color = Color.WhiteSmoke;
            }

            // 채팅 Login 다이얼로그 초기화
            {
                m_chatting_login_count = 0;
                m_chatting_login_queue = new List<Int32>();

                Chatting_Login.Titles.Clear();  Chatting_Login.ChartAreas.Clear();
                Chatting_Login.Legends.Clear(); Chatting_Login.Series.Clear();

                Chatting_Login.BackColor = Color.FromArgb(70, 70, 70);

                Chatting_Login.Titles.Add("Chatting Login");
                Chatting_Login.Titles[0].BackColor = Color.DimGray;
                Chatting_Login.Titles[0].Font = m_dialog_title_font;
                Chatting_Login.Titles[0].Position = m_dialog_title_position;
                Chatting_Login.Titles[0].Alignment = ContentAlignment.TopLeft;

                Chatting_Login.ChartAreas.Add("chatting_login");
                Chatting_Login.ChartAreas["chatting_login"].BackColor = Color.FromArgb(70, 70, 70);
                Chatting_Login.ChartAreas["chatting_login"].Position = m_dialog_chatarea_position;
                Chatting_Login.ChartAreas["chatting_login"].AxisY.MajorGrid.LineColor = Color.Black;
                Chatting_Login.ChartAreas["chatting_login"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Chatting_Login.ChartAreas["chatting_login"].AxisX.Enabled = AxisEnabled.False;

                Chatting_Login.Series.Add("login_series");
                Chatting_Login.Series[0].ChartType = SeriesChartType.Line;
                Chatting_Login.Series[0].Color = Color.WhiteSmoke;
            }

            // 채팅 Room 다이얼로그 초기화
            {
                m_chatting_room_count = 0;
                m_chatting_room_queue = new List<Int32>();

                Chatting_Room.Titles.Clear();  Chatting_Room.ChartAreas.Clear();
                Chatting_Room.Legends.Clear(); Chatting_Room.Series.Clear();

                Chatting_Room.BackColor = Color.FromArgb(70, 70, 70);

                Chatting_Room.Titles.Add("Chatting Room");
                Chatting_Room.Titles[0].BackColor = Color.DimGray;
                Chatting_Room.Titles[0].Font = m_dialog_title_font;
                Chatting_Room.Titles[0].Position = m_dialog_title_position;
                Chatting_Room.Titles[0].Alignment = ContentAlignment.TopLeft;

                Chatting_Room.ChartAreas.Add("chatting_room");
                Chatting_Room.ChartAreas["chatting_room"].BackColor = Color.FromArgb(70, 70, 70);
                Chatting_Room.ChartAreas["chatting_room"].Position = m_dialog_chatarea_position;
                Chatting_Room.ChartAreas["chatting_room"].AxisY.MajorGrid.LineColor = Color.Black;
                Chatting_Room.ChartAreas["chatting_room"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
                Chatting_Room.ChartAreas["chatting_room"].AxisX.Enabled = AxisEnabled.False;

                Chatting_Room.Series.Add("room_series");
                Chatting_Room.Series[0].ChartType = SeriesChartType.Line;
                Chatting_Room.Series[0].Color = Color.WhiteSmoke;
            }

            // 매칭 CPU 다이얼로그 초기화

            // 매칭 Memory 다이얼로그 초기화

            // 매칭 chart1 다이얼로그 초기화

            // 매칭 chart2 다이얼로그 초기화

            // 배틀 CPU 다이얼로그 초기화

            // 배틀 Memory 다이얼로그 초기화

            // 배틀 chart1 다이얼로그 초기화

            // 배틀 chart2 다이얼로그 초기화



            // Timer 초기화
            {
                System.Timers.Timer timer = new System.Timers.Timer();
                timer.Interval = 1200;
                timer.Elapsed += new ElapsedEventHandler(CallBackTimer);
                timer.Start();
            }
        }

        //
        void CallBackTimer(object sender, ElapsedEventArgs e)
        {
            this.Invalidate();
        }

        //
        protected override void OnPaint(PaintEventArgs e)
        {
            /*
             * ---------------------------
             * 각 서브 다이얼로그 함수 호출
             * ---------------------------
             */

            // 프로세서 다이얼로그
            Processor_CPU_dialog();
            Processor_Memory_dialog();
            Processor_Network_dialog();
            Processor_Nonpage_dialog();

            // 채팅서버 다이얼로그
            Chatting_Power();
            Chatting_CPU_dialog();
            Chatting_Memory_dialog();
            Chatting_Packet_dialog();
            Chatting_Session_dialog();
            Chatting_Login_dialog();
            Chatting_Room_dialog();
            
            // 매칭서버 다이얼로그
            Matching_Power();



            // 배틀서버 다이얼로그
            Battle_Power();
        }

        
        private void Matching_Power()
        {
            m_GUI_graphic = this.CreateGraphics();
            m_GUI_graphic.FillRectangle(m_GUI_brush, m_matching_rectangle);

            if (m_matching_power_flag == false)
            {
                m_matching_disconnect.ForeColor = Color.Red;
                m_matching_disconnect.BackColor = Color.FromArgb(50, 50, 50);
                m_matching_disconnect.Font = m_GUI_subbody_font;
                m_matching_disconnect.Location = m_matching_disconnect_point;
                m_matching_disconnect.Size = m_matching_disconnect_size;
                m_matching_disconnect.Text = "disconnect";
                m_matching_disconnect.Parent = this;

                m_matching_body.ForeColor = Color.White;
                m_matching_body.BackColor = Color.FromArgb(50, 50, 50);
                m_matching_body.Font = m_GUI_off_body_font;
                m_matching_body.Location = m_matching_off_body_point;
                m_matching_body.Size = m_matching_off_body_size;
                m_matching_body.Text = "OFF";
                m_matching_body.Parent = this;
            }
            else
            {
                m_matching_connect.ForeColor = Color.Green;
                m_matching_connect.BackColor = Color.FromArgb(50, 50, 50);
                m_matching_connect.Font = m_GUI_subbody_font;
                m_matching_connect.Location = m_matching_connect_point;
                m_matching_connect.Size = m_matching_connect_size;
                m_matching_connect.Text = "connect";
                m_matching_connect.Parent = this;

                m_matching_body.ForeColor = Color.White;
                m_matching_body.BackColor = Color.FromArgb(50, 50, 50);
                m_matching_body.Font = m_GUI_on_body_font;
                m_matching_body.Location = m_matching_on_body_point;
                m_matching_body.Size = m_matching_on_body_size;
                m_matching_body.Text = "ON";
                m_matching_body.Parent = this;

                m_matching_head.ForeColor = Color.White;
            }

            m_matching_head.BackColor = Color.DimGray;
            m_matching_head.Location = m_matching_head_point;
            m_matching_head.Size = m_matching_head_size;
            m_matching_head.Font = m_GUI_head_font;
            m_matching_head.Text = "    매칭서버";
            m_matching_head.Parent = this;
        }

        private void Battle_Power()
        {
            m_GUI_graphic = this.CreateGraphics();
            m_GUI_graphic.FillRectangle(m_GUI_brush, m_battle_rectangle);

            if (m_battle_power_flag == false)
            {
                m_battle_disconnect.ForeColor = Color.Red;
                m_battle_disconnect.BackColor = Color.FromArgb(50, 50, 50);
                m_battle_disconnect.Font = m_GUI_subbody_font;
                m_battle_disconnect.Location = m_battle_disconnect_point;
                m_battle_disconnect.Size = m_battle_disconnect_size;
                m_battle_disconnect.Text = "disconnect";
                m_battle_disconnect.Parent = this;

                m_battle_body.ForeColor = Color.White;
                m_battle_body.BackColor = Color.FromArgb(50, 50, 50);
                m_battle_body.Font = m_GUI_off_body_font;
                m_battle_body.Location = m_battle_off_body_point;
                m_battle_body.Size = m_battle_off_body_size;
                m_battle_body.Text = "OFF";
                m_battle_body.Parent = this;
            }
            else
            {
                m_battle_connect.ForeColor = Color.Green;
                m_battle_connect.BackColor = Color.FromArgb(50, 50, 50);
                m_battle_connect.Font = m_GUI_subbody_font;
                m_battle_connect.Location = m_battle_connect_point;
                m_battle_connect.Size = m_battle_connect_size;
                m_battle_connect.Text = "connect";
                m_battle_connect.Parent = this;

                m_battle_body.ForeColor = Color.White;
                m_battle_body.BackColor = Color.FromArgb(50, 50, 50);
                m_battle_body.Font = m_GUI_on_body_font;
                m_battle_body.Location = m_battle_on_body_point;
                m_battle_body.Size = m_battle_on_body_size;
                m_battle_body.Text = "ON";
                m_battle_body.Parent = this;

                m_battle_head.ForeColor = Color.White;
            }

            m_battle_head.BackColor = Color.DimGray;
            m_battle_head.Location = m_battle_head_point;
            m_battle_head.Size = m_battle_head_size;
            m_battle_head.Font = m_GUI_head_font;
            m_battle_head.Text = "    배틀서버";
            m_battle_head.Parent = this;
        }
        
        private void Processor_CPU_dialog()
        {
            Int32 lo_value = 0;

            if (m_processor_cpu_flag == true)
                Processor_CPU.Titles[0].ForeColor = Color.White;
            else
                Processor_CPU.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_processor_cpu_count))
            {
                Monitor.Enter(m_process_cpu_lock);
                m_processor_cpu_queue.Add(0);
                Monitor.Exit(m_process_cpu_lock);
            }

            if (m_processor_cpu_queue.Count != 0)
            {
                m_process_cpu_accum++;

                if (Processor_CPU.Series[0].Points.Count != 0)
                    Processor_CPU.Series[0].Points[Processor_CPU.Series[0].Points.Count - 1].Label = "";

                if (250 <= Processor_CPU.Series[0].Points.Count)
                {
                    if(m_process_cpu_accum == 5 && 2 <= Processor_CPU.Series[0].Points.Count)
                    {
                        Processor_CPU.Series[0].Points.RemoveAt(0);
                        Processor_CPU.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Processor_CPU.Series[0].Points.RemoveAt(0);                             
                }

                if(m_process_cpu_accum == 5 && 2 <= m_processor_cpu_queue.Count)
                {
                    lo_value = m_processor_cpu_queue[1];
                    Processor_CPU.Series[0].Points.AddY(m_processor_cpu_queue[0]);
                    Processor_CPU.Series[0].Points.AddY(m_processor_cpu_queue[1]);

                    Monitor.Enter(m_process_cpu_lock);
                    m_processor_cpu_queue.RemoveAt(0);
                    m_processor_cpu_queue.RemoveAt(0);
                    Monitor.Exit(m_process_cpu_lock);

                    m_process_cpu_accum = 0;
                }
                else
                {
                    lo_value = m_processor_cpu_queue[0];
                    Processor_CPU.Series[0].Points.AddY(m_processor_cpu_queue[0]);

                    Monitor.Enter(m_process_cpu_lock);
                    m_processor_cpu_queue.RemoveAt(0);
                    Monitor.Exit(m_process_cpu_lock);

                    if (5 <= m_process_cpu_accum)
                        m_process_cpu_accum = 0;
                }

                if (90 <= lo_value)
                    m_processor_cpu_flag = false;                                   
                else
                    m_processor_cpu_flag = true;                

                if(1 <= Processor_CPU.Series[0].Points.Count)
                {
                    Processor_CPU.Series[0].Points[Processor_CPU.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Processor_CPU.Series[0].Points[Processor_CPU.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }            
            }
        }

        private void Processor_Memory_dialog()
        {
            Int32 lo_value = 0;

            if (m_processor_memory_flag == true)
                Processor_Memory.Titles[0].ForeColor = Color.White;
            else
                Processor_Memory.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_processor_memory_count))
                m_processor_memory_queue.Add(0);

            if (m_processor_memory_queue.Count != 0)
            {
                m_process_memory_accum++;

                if (Processor_Memory.Series[0].Points.Count != 0)
                    Processor_Memory.Series[0].Points[Processor_Memory.Series[0].Points.Count - 1].Label = "";

                if (250 <= Processor_Memory.Series[0].Points.Count)
                {
                    if (m_process_memory_accum == 5 && 2 <= m_processor_memory_queue.Count)
                    {
                        Processor_Memory.Series[0].Points.RemoveAt(0);
                        Processor_Memory.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Processor_Memory.Series[0].Points.RemoveAt(0);
                }

                if (m_process_memory_accum == 5 && 2 <= m_processor_memory_queue.Count)
                {
                    lo_value = m_processor_memory_queue[1];
                    Processor_Memory.Series[0].Points.AddY(m_processor_memory_queue[0]);
                    Processor_Memory.Series[0].Points.AddY(m_processor_memory_queue[1]);

                    Monitor.Enter(m_process_memory_lock);
                    m_processor_memory_queue.RemoveAt(0);
                    m_processor_memory_queue.RemoveAt(0);
                    Monitor.Exit(m_process_memory_lock);

                    m_process_memory_accum = 0;
                }
                else
                {
                    lo_value = m_processor_memory_queue[0];
                    Processor_Memory.Series[0].Points.AddY(m_processor_memory_queue[0]);

                    Monitor.Enter(m_process_memory_lock);
                    m_processor_memory_queue.RemoveAt(0);
                    Monitor.Exit(m_process_memory_lock);

                    if (5 <= m_process_memory_accum)
                        m_process_memory_accum = 0;
                }

                if(1 <= Processor_Memory.Series[0].Points.Count)
                {
                    Processor_Memory.Series[0].Points[Processor_Memory.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Processor_Memory.Series[0].Points[Processor_Memory.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }             
            }
        }

        private void Processor_Network_dialog()
        {
            Int32 lo_recv_value = 0, lo_send_value = 0;

            if (m_processor_network_flag == true)
                Processor_Network.Titles[0].ForeColor = Color.White;
            else
                Processor_Network.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_processor_recv_count))
                m_processor_recv_queue.Add(0);

            if (m_processor_recv_queue.Count != 0)
            {
                m_process_recv_accum++;

                if (Processor_Network.Series[0].Points.Count != 0)
                    Processor_Network.Series[0].Points[Processor_Network.Series[0].Points.Count - 1].Label = "";

                if (250 <= Processor_Network.Series[0].Points.Count)
                {
                    if (m_process_recv_accum == 5 && 2 <= m_processor_recv_queue.Count)
                    {
                        Processor_Network.Series[0].Points.RemoveAt(0);
                        Processor_Network.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Processor_Network.Series[0].Points.RemoveAt(0);
                }

                if (m_process_recv_accum == 5 && 2 <= m_processor_recv_queue.Count)
                {
                    lo_recv_value = m_processor_recv_queue[1];
                    Processor_Network.Series[0].Points.AddY(m_processor_recv_queue[0]);
                    Processor_Network.Series[0].Points.AddY(m_processor_recv_queue[1]);

                    Monitor.Enter(m_process_recv_lock);
                    m_processor_recv_queue.RemoveAt(0);
                    m_processor_recv_queue.RemoveAt(0);
                    Monitor.Exit(m_process_recv_lock);

                    m_process_recv_accum = 0;
                }
                else
                {
                    lo_recv_value = m_processor_recv_queue[0];
                    Processor_Network.Series[0].Points.AddY(m_processor_recv_queue[0]);

                    Monitor.Enter(m_process_recv_lock);
                    m_processor_recv_queue.RemoveAt(0);
                    Monitor.Exit(m_process_recv_lock);

                    if (5 <= m_process_recv_accum)
                        m_process_recv_accum = 0;
                }

                if (1 <= Processor_Network.Series[0].Points.Count)
                {
                    Processor_Network.Series[0].Points[Processor_Network.Series[0].Points.Count - 1].Label = lo_recv_value.ToString();
                    Processor_Network.Series[0].Points[Processor_Network.Series[0].Points.Count - 1].LabelForeColor = Color.DarkOrange;
                }
            }

            if (2 <= Interlocked.Increment(ref m_processor_send_count))
                m_processor_send_queue.Add(0);

            if (m_processor_send_queue.Count != 0)
            {
                m_process_send_accum++;

                if (Processor_Network.Series[1].Points.Count != 0)
                    Processor_Network.Series[1].Points[Processor_Network.Series[1].Points.Count - 1].Label = "";

                if (250 <= Processor_Network.Series[1].Points.Count)
                {
                    if (m_process_send_accum == 5 && 2 <= m_processor_send_queue.Count)
                    {
                        Processor_Network.Series[1].Points.RemoveAt(0);
                        Processor_Network.Series[1].Points.RemoveAt(0);
                    }
                    else
                        Processor_Network.Series[1].Points.RemoveAt(0);
                }

                if (m_process_send_accum == 5 && 2 <= m_processor_send_queue.Count)
                {
                    lo_send_value = m_processor_send_queue[1];
                    Processor_Network.Series[1].Points.AddY(m_processor_send_queue[0]);
                    Processor_Network.Series[1].Points.AddY(m_processor_send_queue[1]);

                    Monitor.Enter(m_process_send_lock);
                    m_processor_send_queue.RemoveAt(0);
                    m_processor_send_queue.RemoveAt(0);
                    Monitor.Exit(m_process_send_lock);

                    m_process_send_accum = 0;
                }
                else
                {
                    lo_send_value = m_processor_send_queue[0];
                    Processor_Network.Series[1].Points.AddY(m_processor_send_queue[0]);

                    Monitor.Enter(m_process_send_lock);
                    m_processor_send_queue.RemoveAt(0);
                    Monitor.Exit(m_process_send_lock);

                    if (5 <= m_process_send_accum)
                        m_process_send_accum = 0;
                }

                if (1 <= Processor_Network.Series[1].Points.Count)
                {
                    Processor_Network.Series[1].Points[Processor_Network.Series[1].Points.Count - 1].Label = lo_send_value.ToString();
                    Processor_Network.Series[1].Points[Processor_Network.Series[1].Points.Count - 1].LabelForeColor = Color.OrangeRed;
                }
            }
        }

        private void Processor_Nonpage_dialog()
        {
            Int32 lo_value = 0;

            if (m_processor_nonpage_flag == true)
                Processor_Nonpage.Titles[0].ForeColor = Color.White;
            else
                Processor_Nonpage.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_processor_nonpage_count))
                m_processor_nonpage_queue.Add(0);

            if (m_processor_nonpage_queue.Count != 0)
            {
                m_process_nonpage_accum++;

                if (Processor_Nonpage.Series[0].Points.Count != 0)
                    Processor_Nonpage.Series[0].Points[Processor_Nonpage.Series[0].Points.Count - 1].Label = "";

                if (250 <= Processor_Nonpage.Series[0].Points.Count)
                {
                    if (m_process_nonpage_accum == 5 && 2 <= m_processor_nonpage_queue.Count)
                    {
                        Processor_Nonpage.Series[0].Points.RemoveAt(0);
                        Processor_Nonpage.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Processor_Nonpage.Series[0].Points.RemoveAt(0);
                }

                if (m_process_nonpage_accum == 5 && 2 <= m_processor_nonpage_queue.Count)
                {
                    lo_value = m_processor_nonpage_queue[1];
                    Processor_Nonpage.Series[0].Points.AddY(m_processor_nonpage_queue[0]);
                    Processor_Nonpage.Series[0].Points.AddY(m_processor_nonpage_queue[1]);

                    Monitor.Enter(m_process_nonpage_lock);
                    m_processor_nonpage_queue.RemoveAt(0);
                    m_processor_nonpage_queue.RemoveAt(0);
                    Monitor.Exit(m_process_nonpage_lock);

                    m_process_nonpage_accum = 0;
                }
                else
                {
                    lo_value = m_processor_nonpage_queue[0];
                    Processor_Nonpage.Series[0].Points.AddY(m_processor_nonpage_queue[0]);

                    Monitor.Enter(m_process_nonpage_lock);
                    m_processor_nonpage_queue.RemoveAt(0);
                    Monitor.Exit(m_process_nonpage_lock);

                    if (5 <= m_process_nonpage_accum)
                        m_process_nonpage_accum = 0;
                }

                if (1 <= Processor_Nonpage.Series[0].Points.Count)
                {
                    Processor_Nonpage.Series[0].Points[Processor_Nonpage.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Processor_Nonpage.Series[0].Points[Processor_Nonpage.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }        
            }
        }

        private void Chatting_Power()
        {
            Int32 lo_count = Interlocked.Increment(ref m_chatting_power_count);
            if (lo_count <= 4)
                m_chatting_power_flag = true;
            else
                m_chatting_power_flag = false;

            m_GUI_graphic = this.CreateGraphics();
            m_GUI_graphic.FillRectangle(m_GUI_brush, m_chatting_rectangle);

            if (m_chatting_power_flag == false)
            {
                m_chatting_subbody.ForeColor = Color.Red;
                m_chatting_subbody.BackColor = Color.FromArgb(50, 50, 50);
                m_chatting_subbody.Font = m_GUI_subbody_font;
                m_chatting_subbody.Location = m_chatting_disconnect_point;
                m_chatting_subbody.Size = m_chatting_disconnect_size;
                m_chatting_subbody.Text = "disconnect";
                m_chatting_subbody.Parent = this;

                m_chatting_body.ForeColor = Color.White;
                m_chatting_body.BackColor = Color.FromArgb(50, 50, 50);
                m_chatting_body.Font = m_GUI_off_body_font;
                m_chatting_body.Location = m_chatting_off_body_point;
                m_chatting_body.Size = m_chatting_off_body_size;
                m_chatting_body.Text = "OFF";
                m_chatting_body.Parent = this;
            }

            else
            {
                m_chatting_subbody.ForeColor = Color.Green;
                m_chatting_subbody.BackColor = Color.FromArgb(50, 50, 50);
                m_chatting_subbody.Font = m_GUI_subbody_font;
                m_chatting_subbody.Location = m_chatting_connect_point;
                m_chatting_subbody.Size = m_chatting_connect_size;
                m_chatting_subbody.Text = "connect";
                m_chatting_subbody.Parent = this;

                m_chatting_body.ForeColor = Color.White;
                m_chatting_body.BackColor = Color.FromArgb(50, 50, 50);
                m_chatting_body.Font = m_GUI_on_body_font;
                m_chatting_body.Location = m_chatting_on_body_point;
                m_chatting_body.Size = m_chatting_on_body_size;
                m_chatting_body.Text = "ON";
                m_chatting_body.Parent = this;

                m_chatting_head.ForeColor = Color.White;
            }

            m_chatting_head.BackColor = Color.DimGray;
            m_chatting_head.Location = m_chatting_head_point;
            m_chatting_head.Size = m_chatting_head_size;
            m_chatting_head.Font = m_GUI_head_font;
            m_chatting_head.Text = "    채팅서버";
            m_chatting_head.Parent = this;
        }
        
        private void Chatting_CPU_dialog()
        {
            Int32 lo_value = 0;

            if (m_chatting_cpu_flag == true)
                Chatting_CPU.Titles[0].ForeColor = Color.White;

            if (2 <= Interlocked.Increment(ref m_chatting_cpu_count))
                m_chatting_cpu_queue.Add(0);

            if (m_chatting_cpu_queue.Count != 0)
            {
                m_chatting_cpu_accum++;

                if(Chatting_CPU.Series[0].Points.Count != 0)
                    Chatting_CPU.Series[0].Points[Chatting_CPU.Series[0].Points.Count - 1].Label = "";

                if (250 <= Chatting_CPU.Series[0].Points.Count)
                {
                    if (m_chatting_cpu_accum == 5 && 2 <= m_chatting_cpu_queue.Count)
                    {
                        Chatting_CPU.Series[0].Points.RemoveAt(0);
                        Chatting_CPU.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Chatting_CPU.Series[0].Points.RemoveAt(0);
                }

                if (m_chatting_cpu_accum == 5 && 2 <= m_chatting_cpu_queue.Count)
                {
                    lo_value = m_chatting_cpu_queue[1];
                    Chatting_CPU.Series[0].Points.AddY(m_chatting_cpu_queue[0]);
                    Chatting_CPU.Series[0].Points.AddY(m_chatting_cpu_queue[1]);

                    Monitor.Enter(m_chatting_cpu_lock);
                    m_chatting_cpu_queue.RemoveAt(0);
                    m_chatting_cpu_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_cpu_lock);

                    m_chatting_cpu_accum = 0;
                }
                else
                {
                    lo_value = m_chatting_cpu_queue[0];
                    Chatting_CPU.Series[0].Points.AddY(m_chatting_cpu_queue[0]);

                    Monitor.Enter(m_chatting_cpu_lock);
                    m_chatting_cpu_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_cpu_lock);

                    if (5 <= m_chatting_cpu_accum)
                        m_chatting_cpu_accum = 0;
                }

                if (1 <= Chatting_CPU.Series[0].Points.Count)
                {
                    Chatting_CPU.Series[0].Points[Chatting_CPU.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Chatting_CPU.Series[0].Points[Chatting_CPU.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }           
            }
        }

        private void Chatting_Memory_dialog()
        {
            Int32 lo_value = 0;

            if (m_chatting_memory_flag == true)
                Chatting_Memory.Titles[0].ForeColor = Color.White;
            else
                Chatting_Memory.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_chatting_memory_count))
                m_chatting_memory_queue.Add(0);

            if (m_chatting_memory_queue.Count != 0)
            {
                m_chatting_memory_accum++;
                
                if (Chatting_Memory.Series[0].Points.Count != 0)
                    Chatting_Memory.Series[0].Points[Chatting_Memory.Series[0].Points.Count - 1].Label = "";

                if (250 <= Chatting_Memory.Series[0].Points.Count)
                {
                    if (m_chatting_memory_accum == 5 && 2 <= m_chatting_memory_queue.Count)
                    {
                        Chatting_Memory.Series[0].Points.RemoveAt(0);
                        Chatting_Memory.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Chatting_Memory.Series[0].Points.RemoveAt(0);
                }

                if (m_chatting_memory_accum == 5 && 2 <= m_chatting_memory_queue.Count)
                {
                    lo_value = m_chatting_memory_queue[1];
                    Chatting_Memory.Series[0].Points.AddY(m_chatting_memory_queue[0]);
                    Chatting_Memory.Series[0].Points.AddY(m_chatting_memory_queue[1]);

                    Monitor.Enter(m_chatting_memory_lock);
                    m_chatting_memory_queue.RemoveAt(0);
                    m_chatting_memory_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_memory_lock);

                    m_chatting_memory_accum = 0;
                }
                else
                {
                    lo_value = m_chatting_memory_queue[0];
                    Chatting_Memory.Series[0].Points.AddY(m_chatting_memory_queue[0]);

                    Monitor.Enter(m_chatting_memory_lock);
                    m_chatting_memory_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_memory_lock);

                    if (5 <= m_chatting_memory_accum)
                        m_chatting_memory_accum = 0;
                }

                if (1 <= Chatting_Memory.Series[0].Points.Count)
                {
                    Chatting_Memory.Series[0].Points[Chatting_Memory.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Chatting_Memory.Series[0].Points[Chatting_Memory.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }       
            }
        }

        private void Chatting_Packet_dialog()
        {
            Int32 lo_value = 0;

            if (m_chatting_packet_flag == true)
                Chatting_Packet.Titles[0].ForeColor = Color.White;
            else
                Chatting_Packet.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_chatting_packet_count))
                m_chatting_packet_queue.Add(0);

            if (m_chatting_packet_queue.Count != 0)
            {
                m_chatting_packet_accum++;

                if (Chatting_Packet.Series[0].Points.Count != 0)
                    Chatting_Packet.Series[0].Points[Chatting_Packet.Series[0].Points.Count - 1].Label = "";

                if (250 <= Chatting_Packet.Series[0].Points.Count)
                {
                    if (m_chatting_packet_accum == 5 && 2 <= m_chatting_packet_queue.Count)
                    {
                        Chatting_Packet.Series[0].Points.RemoveAt(0);
                        Chatting_Packet.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Chatting_Packet.Series[0].Points.RemoveAt(0);
                }

                if (m_chatting_packet_accum == 5 && 2 <= m_chatting_packet_queue.Count)
                {
                    lo_value = m_chatting_packet_queue[1];
                    Chatting_Packet.Series[0].Points.AddY(m_chatting_packet_queue[0]);
                    Chatting_Packet.Series[0].Points.AddY(m_chatting_packet_queue[1]);

                    Monitor.Enter(m_chatting_packet_lock);
                    m_chatting_packet_queue.RemoveAt(0);
                    m_chatting_packet_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_packet_lock);

                    m_chatting_packet_accum = 0;
                }
                else
                {
                    lo_value = m_chatting_packet_queue[0];
                    Chatting_Packet.Series[0].Points.AddY(m_chatting_packet_queue[0]);

                    Monitor.Enter(m_chatting_packet_lock);
                    m_chatting_packet_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_packet_lock);

                    if (5 <= m_chatting_packet_accum)
                        m_chatting_packet_accum = 0;
                }

                if (1 <= Chatting_Packet.Series[0].Points.Count)
                {
                    Chatting_Packet.Series[0].Points[Chatting_Packet.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Chatting_Packet.Series[0].Points[Chatting_Packet.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }
            }
        }

        private void Chatting_Session_dialog()
        {
            Int32 lo_value = 0;

            if (m_chatting_session_flag == true)
                Chatting_Session.Titles[0].ForeColor = Color.White;
            else
                Chatting_Session.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_chatting_session_count))
                m_chatting_session_queue.Add(0);

            if (m_chatting_session_queue.Count != 0)
            {
                m_chatting_session_accum++;

                if (Chatting_Session.Series[0].Points.Count != 0)
                    Chatting_Session.Series[0].Points[Chatting_Session.Series[0].Points.Count - 1].Label = "";

                if (250 <= Chatting_Session.Series[0].Points.Count)
                {
                    if (m_chatting_session_accum == 5 && 2 <= m_chatting_session_queue.Count)
                    {
                        Chatting_Session.Series[0].Points.RemoveAt(0);
                        Chatting_Session.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Chatting_Session.Series[0].Points.RemoveAt(0);
                }

                if (m_chatting_session_accum == 5 && 2 <= m_chatting_session_queue.Count)
                {
                    lo_value = m_chatting_session_queue[1];
                    Chatting_Session.Series[0].Points.AddY(m_chatting_session_queue[0]);
                    Chatting_Session.Series[0].Points.AddY(m_chatting_session_queue[1]);

                    Monitor.Enter(m_chatting_session_lock);
                    m_chatting_session_queue.RemoveAt(0);
                    m_chatting_session_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_session_lock);

                    m_chatting_session_accum = 0;
                }
                else
                {
                    lo_value = m_chatting_session_queue[0];
                    Chatting_Session.Series[0].Points.AddY(m_chatting_session_queue[0]);

                    Monitor.Enter(m_chatting_session_lock);
                    m_chatting_session_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_session_lock);

                    if (5 <= m_chatting_session_accum)
                        m_chatting_session_accum = 0;
                }

                if (1 <= Chatting_Session.Series[0].Points.Count)
                {
                    Chatting_Session.Series[0].Points[Chatting_Session.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Chatting_Session.Series[0].Points[Chatting_Session.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }               
            }
        }

        private void Chatting_Login_dialog()
        {
            Int32 lo_value = 0;

            if (m_chatting_login_flag == true)
                Chatting_Login.Titles[0].ForeColor = Color.White;
            else
                Chatting_Login.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_chatting_login_count))
                m_chatting_login_queue.Add(0);

            if (m_chatting_login_queue.Count != 0)
            {
                m_chatting_login_accum++;

                if (Chatting_Login.Series[0].Points.Count != 0)
                    Chatting_Login.Series[0].Points[Chatting_Login.Series[0].Points.Count - 1].Label = "";

                if (250 <= Chatting_Login.Series[0].Points.Count)
                {
                    if (m_chatting_login_accum == 5 && 2 <= m_chatting_login_queue.Count)
                    {
                        Chatting_Login.Series[0].Points.RemoveAt(0);
                        Chatting_Login.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Chatting_Login.Series[0].Points.RemoveAt(0);
                }

                if (m_chatting_login_accum == 5 && 2 <= m_chatting_login_queue.Count)
                {
                    lo_value = m_chatting_login_queue[1];
                    Chatting_Login.Series[0].Points.AddY(m_chatting_login_queue[0]);
                    Chatting_Login.Series[0].Points.AddY(m_chatting_login_queue[1]);

                    Monitor.Enter(m_chatting_login_lock);
                    m_chatting_login_queue.RemoveAt(0);
                    m_chatting_login_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_login_lock);

                    m_chatting_login_accum = 0;
                }
                else
                {
                    lo_value = m_chatting_login_queue[0];
                    Chatting_Login.Series[0].Points.AddY(m_chatting_login_queue[0]);

                    Monitor.Enter(m_chatting_login_lock);
                    m_chatting_login_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_login_lock);

                    if (5 <= m_chatting_login_accum)
                        m_chatting_login_accum = 0;
                }

                if (1 <= Chatting_Login.Series[0].Points.Count)
                {
                    Chatting_Login.Series[0].Points[Chatting_Login.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Chatting_Login.Series[0].Points[Chatting_Login.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }                
            }
        }

        private void Chatting_Room_dialog()
        {
            Int32 lo_value = 0;

            if (m_chatting_room_flag == true)
                Chatting_Room.Titles[0].ForeColor = Color.White;
            else
                Chatting_Room.Titles[0].ForeColor = Color.Red;

            if (2 <= Interlocked.Increment(ref m_chatting_room_count))
                m_chatting_room_queue.Add(0);

            if (m_chatting_room_queue.Count != 0)
            {
                m_chatting_room_accum++;

                if (Chatting_Room.Series[0].Points.Count != 0)
                    Chatting_Room.Series[0].Points[Chatting_Room.Series[0].Points.Count - 1].Label = "";

                if (250 <= Chatting_Room.Series[0].Points.Count)
                {
                    if (m_chatting_room_accum == 5 && 2 <= m_chatting_room_queue.Count)
                    {
                        Chatting_Room.Series[0].Points.RemoveAt(0);
                        Chatting_Room.Series[0].Points.RemoveAt(0);
                    }
                    else
                        Chatting_Room.Series[0].Points.RemoveAt(0);
                }

                if (m_chatting_room_accum == 5 && 2 <= m_chatting_room_queue.Count)
                {
                    lo_value = m_chatting_room_queue[1];
                    Chatting_Room.Series[0].Points.AddY(m_chatting_room_queue[0]);
                    Chatting_Room.Series[0].Points.AddY(m_chatting_room_queue[1]);

                    Monitor.Enter(m_chatting_room_lock);
                    m_chatting_room_queue.RemoveAt(0);
                    m_chatting_room_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_room_lock);

                    m_chatting_room_accum = 0;
                }
                else
                {
                    lo_value = m_chatting_room_queue[0];
                    Chatting_Room.Series[0].Points.AddY(m_chatting_room_queue[0]);

                    Monitor.Enter(m_chatting_room_lock);
                    m_chatting_room_queue.RemoveAt(0);
                    Monitor.Exit(m_chatting_room_lock);

                    if (5 <= m_chatting_room_accum)
                        m_chatting_room_accum = 0;
                }

                if (1 <= Chatting_Room.Series[0].Points.Count)
                {
                    Chatting_Room.Series[0].Points[Chatting_Room.Series[0].Points.Count - 1].Label = lo_value.ToString();
                    Chatting_Room.Series[0].Points[Chatting_Room.Series[0].Points.Count - 1].LabelForeColor = Color.Orange;
                }       
            }
        }

        // 완료
        private void Monitoring_FormClosing(object sender, FormClosingEventArgs e)
        {
            m_network.M_ExitNetwork();
        }
    }
}
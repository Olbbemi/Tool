﻿namespace Monitoring
{
    partial class C_Monitor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend9 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea10 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend10 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea11 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend11 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series11 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea12 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend12 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series12 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea13 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend13 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series13 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea14 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend14 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series14 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea15 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend15 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series15 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea16 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend16 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series16 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea17 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend17 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series17 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea18 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend18 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series18 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.Chatting_CPU = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Chatting_Memory = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Chatting_Session = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Chatting_Packet = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Processor_CPU = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Matching_CPU = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Battle_chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Matching_chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Battle_CPU = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Mathcing_Memory = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Battle_chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Battle_Memory = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Matching_chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Chatting_Login = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Chatting_Room = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Processor_Memory = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Processor_Network = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Processor_Nonpage = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_CPU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Memory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Session)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Packet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Processor_CPU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Matching_CPU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Battle_chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Matching_chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Battle_CPU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mathcing_Memory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Battle_chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Battle_Memory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Matching_chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Login)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Room)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Processor_Memory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Processor_Network)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Processor_Nonpage)).BeginInit();
            this.SuspendLayout();
            // 
            // Chatting_CPU
            // 
            chartArea1.Name = "ChartArea1";
            this.Chatting_CPU.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.Chatting_CPU.Legends.Add(legend1);
            this.Chatting_CPU.Location = new System.Drawing.Point(110, 10);
            this.Chatting_CPU.Name = "Chatting_CPU";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.Chatting_CPU.Series.Add(series1);
            this.Chatting_CPU.Size = new System.Drawing.Size(300, 150);
            this.Chatting_CPU.TabIndex = 7;
            this.Chatting_CPU.Text = "chart4";
            // 
            // Chatting_Memory
            // 
            chartArea2.Name = "ChartArea1";
            this.Chatting_Memory.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.Chatting_Memory.Legends.Add(legend2);
            this.Chatting_Memory.Location = new System.Drawing.Point(415, 10);
            this.Chatting_Memory.Name = "Chatting_Memory";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.Chatting_Memory.Series.Add(series2);
            this.Chatting_Memory.Size = new System.Drawing.Size(335, 150);
            this.Chatting_Memory.TabIndex = 8;
            this.Chatting_Memory.Text = "chart1";
            // 
            // Chatting_Session
            // 
            chartArea3.Name = "ChartArea1";
            this.Chatting_Session.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.Chatting_Session.Legends.Add(legend3);
            this.Chatting_Session.Location = new System.Drawing.Point(1070, 10);
            this.Chatting_Session.Name = "Chatting_Session";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.Chatting_Session.Series.Add(series3);
            this.Chatting_Session.Size = new System.Drawing.Size(320, 150);
            this.Chatting_Session.TabIndex = 9;
            this.Chatting_Session.Text = "chart2";
            // 
            // Chatting_Packet
            // 
            chartArea4.Name = "ChartArea1";
            this.Chatting_Packet.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.Chatting_Packet.Legends.Add(legend4);
            this.Chatting_Packet.Location = new System.Drawing.Point(755, 10);
            this.Chatting_Packet.Name = "Chatting_Packet";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.Chatting_Packet.Series.Add(series4);
            this.Chatting_Packet.Size = new System.Drawing.Size(310, 150);
            this.Chatting_Packet.TabIndex = 10;
            this.Chatting_Packet.Text = "chart3";
            // 
            // Processor_CPU
            // 
            chartArea5.Name = "ChartArea1";
            this.Processor_CPU.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.Processor_CPU.Legends.Add(legend5);
            this.Processor_CPU.Location = new System.Drawing.Point(5, 490);
            this.Processor_CPU.Name = "Processor_CPU";
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.Processor_CPU.Series.Add(series5);
            this.Processor_CPU.Size = new System.Drawing.Size(465, 150);
            this.Processor_CPU.TabIndex = 11;
            this.Processor_CPU.Text = "chart1";
            // 
            // Matching_CPU
            // 
            chartArea6.Name = "ChartArea1";
            this.Matching_CPU.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.Matching_CPU.Legends.Add(legend6);
            this.Matching_CPU.Location = new System.Drawing.Point(120, 170);
            this.Matching_CPU.Name = "Matching_CPU";
            series6.ChartArea = "ChartArea1";
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.Matching_CPU.Series.Add(series6);
            this.Matching_CPU.Size = new System.Drawing.Size(350, 150);
            this.Matching_CPU.TabIndex = 12;
            this.Matching_CPU.Text = "chart4";
            // 
            // Battle_chart2
            // 
            chartArea7.Name = "ChartArea1";
            this.Battle_chart2.ChartAreas.Add(chartArea7);
            legend7.Name = "Legend1";
            this.Battle_chart2.Legends.Add(legend7);
            this.Battle_chart2.Location = new System.Drawing.Point(1200, 330);
            this.Battle_chart2.Name = "Battle_chart2";
            series7.ChartArea = "ChartArea1";
            series7.Legend = "Legend1";
            series7.Name = "Series1";
            this.Battle_chart2.Series.Add(series7);
            this.Battle_chart2.Size = new System.Drawing.Size(350, 150);
            this.Battle_chart2.TabIndex = 13;
            this.Battle_chart2.Text = "chart5";
            // 
            // Matching_chart2
            // 
            chartArea8.Name = "ChartArea1";
            this.Matching_chart2.ChartAreas.Add(chartArea8);
            legend8.Name = "Legend1";
            this.Matching_chart2.Legends.Add(legend8);
            this.Matching_chart2.Location = new System.Drawing.Point(1200, 170);
            this.Matching_chart2.Name = "Matching_chart2";
            series8.ChartArea = "ChartArea1";
            series8.Legend = "Legend1";
            series8.Name = "Series1";
            this.Matching_chart2.Series.Add(series8);
            this.Matching_chart2.Size = new System.Drawing.Size(350, 150);
            this.Matching_chart2.TabIndex = 14;
            this.Matching_chart2.Text = "chart6";
            // 
            // Battle_CPU
            // 
            chartArea9.Name = "ChartArea1";
            this.Battle_CPU.ChartAreas.Add(chartArea9);
            legend9.Name = "Legend1";
            this.Battle_CPU.Legends.Add(legend9);
            this.Battle_CPU.Location = new System.Drawing.Point(120, 330);
            this.Battle_CPU.Name = "Battle_CPU";
            series9.ChartArea = "ChartArea1";
            series9.Legend = "Legend1";
            series9.Name = "Series1";
            this.Battle_CPU.Series.Add(series9);
            this.Battle_CPU.Size = new System.Drawing.Size(350, 150);
            this.Battle_CPU.TabIndex = 15;
            this.Battle_CPU.Text = "chart7";
            // 
            // Mathcing_Memory
            // 
            chartArea10.Name = "ChartArea1";
            this.Mathcing_Memory.ChartAreas.Add(chartArea10);
            legend10.Name = "Legend1";
            this.Mathcing_Memory.Legends.Add(legend10);
            this.Mathcing_Memory.Location = new System.Drawing.Point(480, 170);
            this.Mathcing_Memory.Name = "Mathcing_Memory";
            series10.ChartArea = "ChartArea1";
            series10.Legend = "Legend1";
            series10.Name = "Series1";
            this.Mathcing_Memory.Series.Add(series10);
            this.Mathcing_Memory.Size = new System.Drawing.Size(350, 150);
            this.Mathcing_Memory.TabIndex = 16;
            this.Mathcing_Memory.Text = "chart8";
            // 
            // Battle_chart1
            // 
            chartArea11.Name = "ChartArea1";
            this.Battle_chart1.ChartAreas.Add(chartArea11);
            legend11.Name = "Legend1";
            this.Battle_chart1.Legends.Add(legend11);
            this.Battle_chart1.Location = new System.Drawing.Point(840, 330);
            this.Battle_chart1.Name = "Battle_chart1";
            series11.ChartArea = "ChartArea1";
            series11.Legend = "Legend1";
            series11.Name = "Series1";
            this.Battle_chart1.Series.Add(series11);
            this.Battle_chart1.Size = new System.Drawing.Size(350, 150);
            this.Battle_chart1.TabIndex = 17;
            this.Battle_chart1.Text = "chart9";
            // 
            // Battle_Memory
            // 
            chartArea12.Name = "ChartArea1";
            this.Battle_Memory.ChartAreas.Add(chartArea12);
            legend12.Name = "Legend1";
            this.Battle_Memory.Legends.Add(legend12);
            this.Battle_Memory.Location = new System.Drawing.Point(480, 330);
            this.Battle_Memory.Name = "Battle_Memory";
            series12.ChartArea = "ChartArea1";
            series12.Legend = "Legend1";
            series12.Name = "Series1";
            this.Battle_Memory.Series.Add(series12);
            this.Battle_Memory.Size = new System.Drawing.Size(350, 150);
            this.Battle_Memory.TabIndex = 18;
            this.Battle_Memory.Text = "chart10";
            // 
            // Matching_chart1
            // 
            chartArea13.Name = "ChartArea1";
            this.Matching_chart1.ChartAreas.Add(chartArea13);
            legend13.Name = "Legend1";
            this.Matching_chart1.Legends.Add(legend13);
            this.Matching_chart1.Location = new System.Drawing.Point(840, 170);
            this.Matching_chart1.Name = "Matching_chart1";
            series13.ChartArea = "ChartArea1";
            series13.Legend = "Legend1";
            series13.Name = "Series1";
            this.Matching_chart1.Series.Add(series13);
            this.Matching_chart1.Size = new System.Drawing.Size(350, 150);
            this.Matching_chart1.TabIndex = 19;
            this.Matching_chart1.Text = "chart11";
            // 
            // Chatting_Login
            // 
            chartArea14.Name = "ChartArea1";
            this.Chatting_Login.ChartAreas.Add(chartArea14);
            legend14.Name = "Legend1";
            this.Chatting_Login.Legends.Add(legend14);
            this.Chatting_Login.Location = new System.Drawing.Point(1395, 10);
            this.Chatting_Login.Name = "Chatting_Login";
            series14.ChartArea = "ChartArea1";
            series14.Legend = "Legend1";
            series14.Name = "Series1";
            this.Chatting_Login.Series.Add(series14);
            this.Chatting_Login.Size = new System.Drawing.Size(260, 150);
            this.Chatting_Login.TabIndex = 20;
            this.Chatting_Login.Text = "chart2";
            // 
            // Chatting_Room
            // 
            chartArea15.Name = "ChartArea1";
            this.Chatting_Room.ChartAreas.Add(chartArea15);
            legend15.Name = "Legend1";
            this.Chatting_Room.Legends.Add(legend15);
            this.Chatting_Room.Location = new System.Drawing.Point(1660, 10);
            this.Chatting_Room.Name = "Chatting_Room";
            series15.ChartArea = "ChartArea1";
            series15.Legend = "Legend1";
            series15.Name = "Series1";
            this.Chatting_Room.Series.Add(series15);
            this.Chatting_Room.Size = new System.Drawing.Size(235, 150);
            this.Chatting_Room.TabIndex = 22;
            this.Chatting_Room.Text = "chart4";
            // 
            // Processor_Memory
            // 
            chartArea16.Name = "ChartArea1";
            this.Processor_Memory.ChartAreas.Add(chartArea16);
            legend16.Name = "Legend1";
            this.Processor_Memory.Legends.Add(legend16);
            this.Processor_Memory.Location = new System.Drawing.Point(480, 490);
            this.Processor_Memory.Name = "Processor_Memory";
            series16.ChartArea = "ChartArea1";
            series16.Legend = "Legend1";
            series16.Name = "Series1";
            this.Processor_Memory.Series.Add(series16);
            this.Processor_Memory.Size = new System.Drawing.Size(465, 150);
            this.Processor_Memory.TabIndex = 23;
            this.Processor_Memory.Text = "chart2";
            // 
            // Processor_Network
            // 
            chartArea17.Name = "ChartArea1";
            this.Processor_Network.ChartAreas.Add(chartArea17);
            legend17.Name = "Legend1";
            this.Processor_Network.Legends.Add(legend17);
            this.Processor_Network.Location = new System.Drawing.Point(955, 490);
            this.Processor_Network.Name = "Processor_Network";
            series17.ChartArea = "ChartArea1";
            series17.Legend = "Legend1";
            series17.Name = "Series1";
            this.Processor_Network.Series.Add(series17);
            this.Processor_Network.Size = new System.Drawing.Size(465, 150);
            this.Processor_Network.TabIndex = 24;
            this.Processor_Network.Text = "chart3";
            // 
            // Processor_Nonpage
            // 
            chartArea18.Name = "ChartArea1";
            this.Processor_Nonpage.ChartAreas.Add(chartArea18);
            legend18.Name = "Legend1";
            this.Processor_Nonpage.Legends.Add(legend18);
            this.Processor_Nonpage.Location = new System.Drawing.Point(1430, 490);
            this.Processor_Nonpage.Name = "Processor_Nonpage";
            series18.ChartArea = "ChartArea1";
            series18.Legend = "Legend1";
            series18.Name = "Series1";
            this.Processor_Nonpage.Series.Add(series18);
            this.Processor_Nonpage.Size = new System.Drawing.Size(465, 150);
            this.Processor_Nonpage.TabIndex = 25;
            this.Processor_Nonpage.Text = "chart4";
            // 
            // C_Monitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 619);
            this.Controls.Add(this.Processor_Nonpage);
            this.Controls.Add(this.Processor_Network);
            this.Controls.Add(this.Processor_Memory);
            this.Controls.Add(this.Chatting_Room);
            this.Controls.Add(this.Chatting_Login);
            this.Controls.Add(this.Matching_chart1);
            this.Controls.Add(this.Battle_Memory);
            this.Controls.Add(this.Battle_chart1);
            this.Controls.Add(this.Mathcing_Memory);
            this.Controls.Add(this.Battle_CPU);
            this.Controls.Add(this.Matching_chart2);
            this.Controls.Add(this.Battle_chart2);
            this.Controls.Add(this.Matching_CPU);
            this.Controls.Add(this.Processor_CPU);
            this.Controls.Add(this.Chatting_Packet);
            this.Controls.Add(this.Chatting_Session);
            this.Controls.Add(this.Chatting_Memory);
            this.Controls.Add(this.Chatting_CPU);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "C_Monitor";
            this.Text = "Monitoring";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Monitoring_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_CPU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Memory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Session)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Packet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Processor_CPU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Matching_CPU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Battle_chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Matching_chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Battle_CPU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mathcing_Memory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Battle_chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Battle_Memory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Matching_chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Login)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chatting_Room)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Processor_Memory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Processor_Network)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Processor_Nonpage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart Chatting_CPU;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chatting_Memory;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chatting_Session;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chatting_Packet;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chatting_Login;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chatting_Room;
        private System.Windows.Forms.DataVisualization.Charting.Chart Processor_CPU;
        private System.Windows.Forms.DataVisualization.Charting.Chart Matching_CPU;
        private System.Windows.Forms.DataVisualization.Charting.Chart Battle_chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart Matching_chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart Battle_CPU;
        private System.Windows.Forms.DataVisualization.Charting.Chart Mathcing_Memory;
        private System.Windows.Forms.DataVisualization.Charting.Chart Battle_chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart Battle_Memory;
        private System.Windows.Forms.DataVisualization.Charting.Chart Matching_chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart Processor_Memory;
        private System.Windows.Forms.DataVisualization.Charting.Chart Processor_Network;
        private System.Windows.Forms.DataVisualization.Charting.Chart Processor_Nonpage;
    }
}
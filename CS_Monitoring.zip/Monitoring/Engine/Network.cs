﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;

using Log;
using Monitoring;
using Protocol;
using RingBuffer;
using SerializeBuffer;

namespace Network
{
    class C_Network
    {
        class Session
        {
            [StructLayout(LayoutKind.Sequential, Pack = 1)]
            internal struct ST_Header
            {
                internal Byte code;
                internal Int16 len;
                internal Byte xor_code;
                internal Byte checksum;
            }

            internal enum E_State : Byte
            {
                none = 0,
                ready = 1,
                running,
                finish
            }

            internal E_State m_state;
            internal Socket m_socket;
            internal C_RingBuffer m_recvQ;
        }

        private enum E_PacketHeadSize : Int16
        {
            contents_header_size = 2,
            net_header_size = 5,
        }

        private enum E_DecodeRetrun : Byte
        {
            check_sum_error = 0,
            packet_code_error,
            success
        }
        
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct ST_RESLogin
        {
            internal Byte status;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct ST_Data
        {
           internal Byte server_no;
           internal Byte data_type;
           internal Int32 data_value;
           internal Int32 time_stamp;
        }

        bool m_is_connect_thread_on, m_is_recv_thread_on, m_is_update_thread_on, m_is_recv_event, m_is_update_event;
        Thread m_connect_thread, m_recv_thread, m_update_thread;
        Session m_session;
        Random m_random;
        C_Monitor m_monitor;


        EventWaitHandle m_connect_event = new EventWaitHandle(false, EventResetMode.AutoReset, ""),
                        m_recv_event = new EventWaitHandle(false, EventResetMode.AutoReset, ""),
                        m_update_event = new EventWaitHandle(false, EventResetMode.AutoReset, "");
            
        public C_Network(C_Monitor p_monitor)
        {
            m_random = new Random();

            m_monitor = p_monitor;
            m_is_connect_thread_on = true;
            m_is_update_thread_on = true;
            m_is_recv_thread_on = true;
            m_is_recv_event = false;
            m_is_update_event = false;

            m_connect_thread = new Thread(new ThreadStart(M_ConnectThread));
            m_update_thread = new Thread(new ThreadStart(M_UpdateThread));
            m_recv_thread = new Thread(new ThreadStart(M_RecvThread));

            m_connect_thread.Start();
            m_update_thread.Start();
            m_recv_thread.Start();

            m_connect_event.Set();
        }

        unsafe private void M_Encode(ref C_SerializeBuffer pa_serialQ)
        {
            Byte m_first_key = 0x32, m_second_key = 0x84; /// 파서로 추출
            Byte m_packet_code = 0x77;

            Byte* serialQ_ptr = (Byte*)pa_serialQ.M_GetBufferPtr();
            Byte lo_mixture_key = (Byte)(m_first_key ^ m_second_key);
            Session.ST_Header lo_header;
            void* lo_buffer_ptr;

            lo_header.code = m_packet_code;
            lo_header.len = (Int16)pa_serialQ.M_GetUsingSize();
            lo_header.xor_code = (Byte)(m_random.Next() & 255);

            lo_header.checksum = 0;
            for (int i = 0; i < lo_header.len; i++)
                lo_header.checksum += serialQ_ptr[i];

            lo_header.xor_code ^= lo_mixture_key;
            lo_header.checksum ^= lo_header.xor_code;

            for (int i = 0; i < lo_header.len; i++)
                serialQ_ptr[i] ^= lo_header.xor_code;

            lo_buffer_ptr = &lo_header;
            pa_serialQ.M_MakeHeader((IntPtr)lo_buffer_ptr, sizeof(Session.ST_Header));
        }

        unsafe private E_DecodeRetrun M_Decode(C_SerializeBuffer pa_serialQ, ref Byte pa_check_sum)
        {
            Byte m_first_key = 0x32, m_second_key = 0x84; /// 파서로 추출
            Byte m_packet_code = 0x77;

            Byte lo_mixture_key = (Byte)(m_first_key ^ m_second_key);
            Byte lo_sum = 0;
            Session.ST_Header* lo_header = (Session.ST_Header*)pa_serialQ.M_GetBufferPtr();
            if (lo_header->code != m_packet_code)
                return E_DecodeRetrun.packet_code_error;

            pa_serialQ.M_MoveFront((Byte)E_PacketHeadSize.net_header_size);
            Byte* lo_serialQ_ptr = (Byte*)((Byte*)lo_header + (Byte)E_PacketHeadSize.net_header_size);

            lo_header->checksum ^= lo_header->xor_code;
            for (int i = 0; i < lo_header->len; i++)
                lo_serialQ_ptr[i] ^= lo_header->xor_code;

            for (int i = 0; i < lo_header->len; i++)
                lo_sum += (Byte)lo_serialQ_ptr[i];

            if (lo_header->checksum != lo_sum)
            {
                pa_check_sum = lo_sum;
                return E_DecodeRetrun.check_sum_error;
            }

            return E_DecodeRetrun.success;
        }

        private void M_Disconnect()
        {
            m_session.m_socket.Close();
            m_session.m_recvQ = null;
            m_session = null;
        }

        public void M_ExitNetwork()
        {
            m_is_connect_thread_on = false;
            m_is_recv_thread_on = false;
            m_is_update_thread_on = false;

            m_connect_event.Set();
            m_recv_event.Set();
            m_update_event.Set();
        }
        
        unsafe private void M_ConnectThread()
        {
            while(true)
            {
                IAsyncResult lo_check = null;

                try
                {
                    m_connect_event.WaitOne();
                }
                catch (ObjectDisposedException object_excp)
                {
                    StackFrame getline = new StackFrame(true);
                    string lo_error = "Errno : " + object_excp.HResult + " | " + "Msg :" + object_excp.Message.ToString();
                    C_Log.M_WriteLog((Byte)C_Log.LOG_STATE.error, getline.GetFileLineNumber(), lo_error);
                }
                catch (AbandonedMutexException abandon_excp)
                {
                    StackFrame getline = new StackFrame(true);
                    string lo_error = "Errno : " + abandon_excp.HResult + " | " + "Msg :" + abandon_excp.Message.ToString();
                    C_Log.M_WriteLog((Byte)C_Log.LOG_STATE.error, getline.GetFileLineNumber(), lo_error);
                }
                catch (InvalidOperationException invalid_excp)
                {
                    StackFrame getline = new StackFrame(true);
                    string lo_error = "Errno : " + invalid_excp.HResult + " | " + "Msg :" + invalid_excp.Message.ToString();
                    C_Log.M_WriteLog((Byte)C_Log.LOG_STATE.error, getline.GetFileLineNumber(), lo_error);
                }

                if (m_is_connect_thread_on == false)
                    break;

                m_session = new Session();
                m_session.m_recvQ = new C_RingBuffer();
                m_session.m_state = (Byte)Session.E_State.none;
                m_session.m_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                try
                {
                    lo_check = m_session.m_socket.BeginConnect("127.0.0.1", 10000, null, null); /// 파서로 추출                   
                }
                catch (SocketException socket_excp)
                {
                    StackFrame getline = new StackFrame(true);
                    string lo_error = "Errno : " + socket_excp.ErrorCode + " | " + "Msg :" + socket_excp.Message.ToString();
                    C_Log.M_WriteLog((Byte)C_Log.LOG_STATE.error, getline.GetFileLineNumber(), lo_error);
                }

                lo_check.AsyncWaitHandle.WaitOne(1000, true);        
                if (m_session.m_socket.Connected != true)
                {
                    m_session.m_socket.Close();
                    m_connect_event.Set();
                    continue;
                }

                m_session.m_socket.EndConnect(lo_check);
                m_session.m_state = Session.E_State.ready;

                m_recv_event.Set();
                m_update_event.Set();

                Int16 lo_type = (Int16)C_Protocol.E_Packet_Type.en_PACKET_CS_MONITOR_TOOL_REQ_LOGIN;
                string lo_session_key = "P09djiwl34jWJV%@oW@#o0d82jvk#cjz"; /// 파서로 추출

                IntPtr lo_session_ptr;
                C_SerializeBuffer lo_serialQ = new C_SerializeBuffer();

                void* lo_type_ptr = &lo_type;
                Byte[] lo_via_session_ptr = Encoding.UTF8.GetBytes(lo_session_key);
                fixed (void* lo_fix_buffer = lo_via_session_ptr)
                    lo_session_ptr = (IntPtr)lo_fix_buffer;

                lo_serialQ.M_Enqueue((IntPtr)lo_type_ptr, sizeof(Int16));
                lo_serialQ.M_Enqueue((IntPtr)lo_session_ptr, lo_session_key.Length);

                M_Encode(ref lo_serialQ);

                Int32 lo_length = lo_serialQ.M_GetUsingSize();
                Byte[] lo_buffer = new Byte[lo_length];
                System.Runtime.InteropServices.Marshal.Copy(lo_serialQ.M_GetBufferPtr(), lo_buffer, 0, lo_length);

                m_session.m_socket.Send(lo_buffer, lo_length, SocketFlags.None);
            }
        }

        unsafe private void M_RecvThread()
        {
            while (m_is_recv_thread_on == true)
            {
                if(m_is_recv_event == false)
                {
                    m_recv_event.WaitOne();
                    m_is_recv_event = true;
                }

                if (m_session.m_state == Session.E_State.ready)
                    m_session.m_state = Session.E_State.running;
                else if (m_session.m_state != Session.E_State.running)
                    continue;

                int lo_recv = 0, lo_size = m_session.m_recvQ.M_LinearRemainRearSize();
                Byte[] lo_buffer = new byte[lo_size];
                IntPtr lo_buffer_ptr;

                try
                {
                    bool lo_check = m_session.m_socket.Poll(1000000, SelectMode.SelectRead);

                    if (lo_check == true)
                        lo_recv = m_session.m_socket.Receive(lo_buffer, lo_size, SocketFlags.None);
                    else
                        continue;
                }
                catch (SocketException socket_excp)
                {
                    StackFrame getline = new StackFrame(true);
                    string lo_error = "Errno : " + socket_excp.ErrorCode + " | " + "Msg :" + socket_excp.Message.ToString();
                    C_Log.M_WriteLog((Byte)C_Log.LOG_STATE.error, getline.GetFileLineNumber(), lo_error);

                    m_session.m_state = Session.E_State.finish;
                    m_is_recv_event = false;
                    continue;
                }

                if(lo_recv == 0)
                {
                    m_session.m_state = Session.E_State.finish;
                    m_is_recv_event = false;
                }  
                else
                {
                    fixed (void* lo_fix_buffer = lo_buffer)
                        lo_buffer_ptr = (IntPtr)lo_fix_buffer;

                    while(true)
                    {
                        bool lo_is_enq_success = m_session.m_recvQ.M_Enqueue(lo_buffer_ptr, lo_recv);
                        if (lo_is_enq_success == true)
                            break;
                    }
                }
            }
        }

        unsafe private void M_UpdateThread()
        {
            while (m_is_update_thread_on == true)
            {
                if (m_is_update_event == false)
                {
                    m_update_event.WaitOne();
                    m_is_update_event = true;
                }

                if (m_session.m_state == Session.E_State.finish)
                {
                    M_Disconnect();
                    m_connect_event.Set();
                    m_is_update_event = false;
                }
                else if (m_session.m_state == Session.E_State.running)
                {
                    while (true)
                    {
                        if (m_session.m_recvQ.M_GetUseSize() < sizeof(Session.ST_Header))
                            break;

                        Session.ST_Header lo_header = new Session.ST_Header();
                        void* lo_header_ptr = (void*)&lo_header;

                        m_session.m_recvQ.M_Peek((IntPtr)lo_header_ptr, sizeof(Session.ST_Header));

                        if (m_session.m_recvQ.M_GetUseSize() < lo_header.len)
                            break;

                        Byte lo_check_sum = 0;
                        C_SerializeBuffer lo_serialQ = new C_SerializeBuffer();
                        
                        while (true)
                        {
                            bool lo_is_deq_success = m_session.m_recvQ.M_Dequeue(lo_serialQ.M_GetBufferPtr(), lo_header.len + sizeof(Session.ST_Header));
                            if (lo_is_deq_success == true)
                                break;
                        }
                        
                        E_DecodeRetrun lo_check = M_Decode(lo_serialQ, ref lo_check_sum);
                        if (lo_check == E_DecodeRetrun.check_sum_error || lo_check == E_DecodeRetrun.check_sum_error)
                        {
                            string lo_error = "";
                            StackFrame getline = new StackFrame(true);

                            switch (lo_check)
                            {
                                case E_DecodeRetrun.check_sum_error:
                                    lo_error = "Error CheckSum: " + lo_check_sum.ToString();
                                    break;

                                case E_DecodeRetrun.packet_code_error:
                                    lo_error = "Error Packet Code: " + lo_header.code.ToString();
                                    break;
                            }

                            C_Log.M_WriteLog((Byte)C_Log.LOG_STATE.error, getline.GetFileLineNumber(), lo_error);
                            m_session.m_state = Session.E_State.finish;
                            break;
                        }

                        M_PacketProc(ref lo_serialQ); 
                    }
                }
            }
        }

        unsafe private void M_PacketProc(ref C_SerializeBuffer pa_serialQ)
        {
            IntPtr lo_ptr = pa_serialQ.M_GetBufferPtr();
            switch(*(Int16*)lo_ptr)
            {
                case (Int16)C_Protocol.E_Packet_Type.en_PACKET_CS_MONITOR_TOOL_RES_LOGIN:
                    M_Login((IntPtr)lo_ptr + (Int16)E_PacketHeadSize.contents_header_size);
                    break;

                case (Int16)C_Protocol.E_Packet_Type.en_PACKET_CS_MONITOR_TOOL_DATA_UPDATE:
                    M_UpdateData((IntPtr)lo_ptr + (Int16)E_PacketHeadSize.contents_header_size);
                    break;
            }
        }

        unsafe void M_Login(IntPtr pa_payload)
        {
            ST_RESLogin* lo_payload = (ST_RESLogin*)pa_payload;

            if (lo_payload->status == 0)
                M_Disconnect();
        }

        unsafe void M_UpdateData(IntPtr pa_payload)
        {
            ST_Data* lo_payload = (ST_Data*)pa_payload;
            Int32 lo_time_stamp = (Int32)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds;

            switch (lo_payload->data_type)
            {
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_SERVER_CPU_TOTAL:
                    if(-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_process_cpu_lock);   
                        m_monitor.m_processor_cpu_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_process_cpu_lock);

                        Interlocked.Exchange(ref m_monitor.m_processor_cpu_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_SERVER_AVAILABLE_MEMORY:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_process_memory_lock);                
                        m_monitor.m_processor_memory_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_process_memory_lock);

                        Interlocked.Exchange(ref m_monitor.m_processor_memory_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_SERVER_NETWORK_RECV:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_process_recv_lock);                        
                        m_monitor.m_processor_recv_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_process_recv_lock);

                        Interlocked.Exchange(ref m_monitor.m_processor_recv_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_SERVER_NETWORK_SEND:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_process_send_lock);                        
                        m_monitor.m_processor_send_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_process_send_lock);

                        Interlocked.Exchange(ref m_monitor.m_processor_send_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_SERVER_NONPAGED_MEMORY:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_process_nonpage_lock);                        
                        m_monitor.m_processor_nonpage_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_process_nonpage_lock);

                        Interlocked.Exchange(ref m_monitor.m_processor_nonpage_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MATCH_SERVER_ON:   break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MATCH_CPU:   break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MATCH_MEMORY_COMMIT:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MATCH_PACKET_POOL:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MATCH_SESSION:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MATCH_PLAYER:   break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MATCH_MATCHSUCCESS:     break;


                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_SERVER_ON:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_CPU:   break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_CPU_SERVER:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_MEMORY_COMMIT:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_PACKET_POOL:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_MATCH_CONNECT:     break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_MATCH_LOGIN:   break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_STAY_CLIENT:   break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_BATTLE_CONNECT:     break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_BATTLE_LOGIN:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_MASTER_BATTLE_STANDBY_ROOM:    break;


                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_SERVER_ON:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_CPU:   break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_MEMORY_COMMIT:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_PACKET_POOL:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_AUTH_FPS:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_GAME_FPS:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_SESSION_ALL:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_SESSION_AUTH:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_SESSION_GAME:   break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_ROOM_WAIT:    break;
                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_BATTLE_ROOM_PLAY:    break;


                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_CHAT_SERVER_ON:
                    Interlocked.Exchange(ref m_monitor.m_chatting_power_count, 0);
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_CHAT_CPU:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_chatting_cpu_lock);                        
                        m_monitor.m_chatting_cpu_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_chatting_cpu_lock);

                        Interlocked.Exchange(ref m_monitor.m_chatting_cpu_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_CHAT_MEMORY_COMMIT:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_chatting_memory_lock);                       
                        m_monitor.m_chatting_memory_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_chatting_memory_lock);

                        Interlocked.Exchange(ref m_monitor.m_chatting_memory_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_CHAT_PACKET_POOL:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_chatting_packet_lock);                       
                        m_monitor.m_chatting_packet_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_chatting_packet_lock);

                        Interlocked.Exchange(ref m_monitor.m_chatting_packet_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_CHAT_SESSION:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_chatting_session_lock);                        
                        m_monitor.m_chatting_session_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_chatting_session_lock);

                        Interlocked.Exchange(ref m_monitor.m_chatting_session_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_CHAT_PLAYER:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_chatting_login_lock);                        
                        m_monitor.m_chatting_login_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_chatting_login_lock);

                        Interlocked.Exchange(ref m_monitor.m_chatting_login_count, 0);
                    }
                    break;

                case (Byte)C_Protocol.E_Packet_Type.dfMONITOR_DATA_TYPE_CHAT_ROOM:
                    if (-500 <= lo_time_stamp - lo_payload->time_stamp && lo_time_stamp - lo_payload->time_stamp <= 1200)
                    {
                        Monitor.Enter(m_monitor.m_chatting_room_lock);                        
                        m_monitor.m_chatting_room_queue.Add(lo_payload->data_value);
                        Monitor.Exit(m_monitor.m_chatting_room_lock);

                        Interlocked.Exchange(ref m_monitor.m_chatting_room_count, 0);
                    }
                    break;      
            }
        }
    }
}
﻿using System;

namespace SerializeBuffer
{
    public class C_SerializeBuffer
    {
        private byte[] m_buffer;
        private Int32 m_front, m_rear;

        private enum E_Initial_Value : Int32
        {
            max_head_size = 5,
            buffer_size = 100
        }

        public C_SerializeBuffer()
        {
            m_buffer = new byte[(Int32)E_Initial_Value.buffer_size];
            m_front = m_rear = (Int32)E_Initial_Value.max_head_size;
        }

        public Int32 M_GetUsingSize()
        {
            return m_rear - m_front;
        }

        public Int32 M_GetUnusingSize()
        {
            return (Int32)E_Initial_Value.buffer_size - m_rear - 1;
        }

        public void M_MoveFront(Int32 p_size)
        {
            m_front += p_size;
        }

        public void M_MoveRear(Int32 p_size)
        {
            m_rear += p_size;
        }

        public void M_MakeHeader(IntPtr p_input_data, Int32 p_size)
        {
            m_front = 0;
            System.Runtime.InteropServices.Marshal.Copy(p_input_data, m_buffer, m_front, p_size);
        }

        unsafe public IntPtr M_GetBufferPtr()
        {
            fixed (Byte* fix_buffer = m_buffer)
                return (IntPtr)(fix_buffer + m_front);
        }

        unsafe public bool M_Enqueue(IntPtr p_input_data, Int32 p_size)
        {
            fixed (Byte* fix_buffer = m_buffer)
            {
                switch (p_size)
                {
                    case 1: *(Byte*)(fix_buffer + m_rear) = *(Byte*)(p_input_data); break;
                    case 2: *(Int16*)(fix_buffer + m_rear) = *(Int16*)(p_input_data); break;
                    case 4: *(Int32*)(fix_buffer + m_rear) = *(Int32*)(p_input_data); break;
                    case 8: *(Int64*)(fix_buffer + m_rear) = *(Int64*)(p_input_data); break;
                    default: System.Runtime.InteropServices.Marshal.Copy(p_input_data, m_buffer, m_rear, p_size); break;
                }
            }

            m_rear += p_size;
            return true;
        }

        unsafe public bool M_Dequeue(IntPtr p_output_data, Int32 p_size)
        {
            if (M_GetUsingSize() < p_size)
                return false;

            fixed (Byte* fix_buffer = m_buffer)
            {
                switch (p_size)
                {
                    case 1: *(Byte*)(p_output_data) = *(Byte*)(fix_buffer + m_front); break;
                    case 2: *(Int16*)(p_output_data) = *(Int16*)(fix_buffer + m_front); break;
                    case 4: *(Int32*)(p_output_data) = *(Int32*)(fix_buffer + m_front); break;
                    case 8: *(Int64*)(p_output_data) = *(Int64*)(fix_buffer + m_front); break;
                    default: System.Runtime.InteropServices.Marshal.Copy(m_buffer, m_front, p_output_data, p_size); break;
                }
            }

            m_front += p_size;
            return true;
        }
    }
}
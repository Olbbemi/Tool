﻿using System;

namespace RingBuffer
{
    public class C_RingBuffer
    {
        Byte[] m_buffer;
        Int32 m_front, m_rear;

        private enum E_Initial_Value : Int32
        {
            buffer_size = 10000
        }

        public C_RingBuffer()
        {
            m_buffer = new byte[(Int32)E_Initial_Value.buffer_size];
            m_front = m_rear = 0;
        }

        unsafe public bool M_Enqueue(IntPtr p_input_data, Int32 p_size)
        {
            Int32 gap, t_front = m_front, t_rear = m_rear, unusing_data = M_GetUnuseSize();

            if ((t_rear + 1) % (Int32)E_Initial_Value.buffer_size == t_front || unusing_data < p_size)
                return false;

            t_rear++;
            if (t_rear == (Int32)E_Initial_Value.buffer_size)
                t_rear = 0;
            gap = (Int32)E_Initial_Value.buffer_size - t_rear;
            fixed (Byte* fix_buffer = m_buffer)
            {
                if (gap < p_size)
                {
                    switch (gap)
                    {
                        case 1: *(Byte*)(fix_buffer + t_rear)  = *(Byte*)p_input_data; break;
                        case 2: *(Int16*)(fix_buffer + t_rear) = *(Int16*)p_input_data; break;
                        case 4: *(Int32*)(fix_buffer + t_rear) = *(Int32*)p_input_data; break;
                        case 8: *(Int64*)(fix_buffer + t_rear) = *(Int64*)p_input_data; break;
                        default: System.Runtime.InteropServices.Marshal.Copy(p_input_data, m_buffer, t_rear, gap); break;
                    }

                    Byte* byte_store = (Byte*)(p_input_data.ToPointer());
                    byte_store += gap;

                    IntPtr intptr_store = (IntPtr)byte_store;

                    System.Runtime.InteropServices.Marshal.Copy(intptr_store, m_buffer, 0, p_size - gap);
                    m_rear = p_size - gap - 1;
                }
                else
                {
                    switch (p_size)
                    {
                        case 1: *(Byte*)(fix_buffer + t_rear)  = *(Byte*)p_input_data; break;
                        case 2: *(Int16*)(fix_buffer + t_rear) = *(Int16*)p_input_data; break;
                        case 4: *(Int32*)(fix_buffer + t_rear) = *(Int32*)p_input_data; break;
                        case 8: *(Int64*)(fix_buffer + t_rear) = *(Int64*)p_input_data; break;
                        default: System.Runtime.InteropServices.Marshal.Copy(p_input_data, m_buffer, t_rear, p_size); break;
                    }

                    if ((Int32)E_Initial_Value.buffer_size <= m_rear + p_size)
                        m_rear += p_size - (Int32)E_Initial_Value.buffer_size;
                    else
                        m_rear += p_size;
                }
            }

            return true;
        }

        unsafe public bool M_Dequeue(IntPtr p_output_data, Int32 p_size)
        {
            Byte* byte_store;
            Int32 gap, t_front = m_front, t_rear = m_rear, using_data = M_GetUseSize();

            if (t_rear == t_front || using_data < p_size)
                return false;

            t_front++;
            if (t_front == (Int32)E_Initial_Value.buffer_size)
                t_front = 0;

            gap = (Int32)E_Initial_Value.buffer_size - t_front;
            fixed (Byte* fix_buffer = m_buffer)
            {
                if (gap < p_size)
                {
                    switch (gap)
                    {
                        case 1: *(Byte*)p_output_data  = *(Byte*)(fix_buffer + t_front); break;
                        case 2: *(Int16*)p_output_data = *(Int16*)(fix_buffer + t_front); break;
                        case 4: *(Int32*)p_output_data = *(Int32*)(fix_buffer + t_front); break;
                        case 8: *(Int64*)p_output_data = *(Int64*)(fix_buffer + t_front); break;
                        default: System.Runtime.InteropServices.Marshal.Copy(m_buffer, t_front, p_output_data, gap); break;
                    }

                    byte_store = (Byte*)(p_output_data.ToPointer()); byte_store += gap;
                    IntPtr intptr_store = (IntPtr)byte_store;

                    System.Runtime.InteropServices.Marshal.Copy(m_buffer, 0, intptr_store, p_size - gap);
                    m_front = p_size - gap - 1;
                }
                else
                {
                    switch (p_size)
                    {
                        case 1: *(Byte*)p_output_data  = *(Byte*)(fix_buffer + t_front); break;
                        case 2: *(Int16*)p_output_data = *(Int16*)(fix_buffer + t_front); break;
                        case 4: *(Int32*)p_output_data = *(Int32*)(fix_buffer + t_front); break;
                        case 8: *(Int64*)p_output_data = *(Int64*)(fix_buffer + t_front); break;
                        default: System.Runtime.InteropServices.Marshal.Copy(m_buffer, t_front, p_output_data, p_size); break;
                    }

                    if ((Int32)E_Initial_Value.buffer_size <= m_front + p_size)
                        m_front += p_size - (Int32)E_Initial_Value.buffer_size;
                    else
                        m_front += p_size;
                }
            }

            return true;
        }

        unsafe public bool M_Peek(IntPtr p_output_data, Int32 p_size)
        {
            Byte* byte_store;
            Int32 gap, temp, t_front = m_front, t_rear = m_rear, using_data = M_GetUseSize();

            if (t_rear == t_front || using_data < p_size)
                return false;

            temp = t_front + 1;
            if (temp == (Int32)E_Initial_Value.buffer_size)
                temp = 0;

            gap = (Int32)E_Initial_Value.buffer_size - temp;
            fixed (Byte* fix_buffer = m_buffer)
            {
                if (gap < p_size)
                {
                    switch (gap)
                    {
                        case 1: *(Byte*)p_output_data  = *(Byte*)(fix_buffer + temp); break;
                        case 2: *(Int16*)p_output_data = *(Int16*)(fix_buffer + temp); break;
                        case 4: *(Int32*)p_output_data = *(Int32*)(fix_buffer + temp); break;
                        case 8: *(Int64*)p_output_data = *(Int64*)(fix_buffer + temp); break;
                        default: System.Runtime.InteropServices.Marshal.Copy(m_buffer, temp, p_output_data, gap); break;
                    }

                    byte_store = (Byte*)(p_output_data.ToPointer()); byte_store += gap;
                    IntPtr intptr_store = (IntPtr)byte_store;

                    System.Runtime.InteropServices.Marshal.Copy(m_buffer, 0, intptr_store, p_size - gap);
                }
                else
                {
                    switch (p_size)
                    {
                        case 1: *(Byte*)p_output_data  = *(Byte*)(fix_buffer + temp); break;
                        case 2: *(Int16*)p_output_data = *(Int16*)(fix_buffer + temp); break;
                        case 4: *(Int32*)p_output_data = *(Int32*)(fix_buffer + temp); break;
                        case 8: *(Int64*)p_output_data = *(Int64*)(fix_buffer + temp); break;
                        default: System.Runtime.InteropServices.Marshal.Copy(m_buffer, temp, p_output_data, p_size); break;
                    }
                }
            }

            return true;
        }

        public void M_MoveFront(Int32 p_size)
        {
            Int32 t_front = m_front;

            t_front += p_size;
            if (t_front >= (Int32)E_Initial_Value.buffer_size)
                t_front -= (Int32)E_Initial_Value.buffer_size;

            m_front = t_front;
        }

        public void M_MoveRear(Int32 p_size)
        {
            Int32 t_rear = m_rear;

            m_rear += p_size;
            if (m_rear >= (Int32)E_Initial_Value.buffer_size)
                m_rear -= (Int32)E_Initial_Value.buffer_size;

            m_rear = t_rear;
        }

        public Int32 M_GetUseSize()
        {
            Int32 t_front = m_front, t_rear = m_rear;

            if (t_front > t_rear)
                return (Int32)E_Initial_Value.buffer_size - (t_front - t_rear);    // (BUFSIZE - 1) - (front - rear) + 1; 
            else
                return t_rear - t_front;
        }

        public Int32 M_GetUnuseSize()
        {
            Int32 t_front = m_front, t_rear = m_rear;

            if (t_front > m_rear)
                return t_front - t_rear - 1;
            else
                return ((Int32)E_Initial_Value.buffer_size - 1) - (t_rear - t_front);
        }

        public Int32 M_LinearRemainFrontSize()
        {
            Int32 t_front = m_front, t_rear = m_rear;

            if (t_front == t_rear)
                return 0;
            else
            {
                Int32 front_temp = t_front + 1;
                if (front_temp == (Int32)E_Initial_Value.buffer_size) front_temp = 0;

                if (front_temp > t_rear)
                    return (Int32)E_Initial_Value.buffer_size - front_temp;
                else
                    return t_rear - front_temp + 1;
            }
        }

        public Int32 M_LinearRemainRearSize()
        {
            Int32 t_front = m_front, t_rear = m_rear;

            Int32 rear_temp = t_rear + 1;
            if (rear_temp == (Int32)E_Initial_Value.buffer_size) rear_temp = 0;

            if (rear_temp >= t_front)
                return (Int32)E_Initial_Value.buffer_size - rear_temp;
            else
                return t_front - rear_temp;
        }

        unsafe public IntPtr M_GetBasicPtr()
        {
            fixed (Byte* fix_buffer = m_buffer)
                return (IntPtr)fix_buffer;
        }

        unsafe public IntPtr M_GetFrontPtr()
        {
            Int32 front_temp = m_front + 1;
            if (front_temp == (Int32)E_Initial_Value.buffer_size)
                front_temp = 0;

            fixed (Byte* fix_buffer = m_buffer)
            {
                return (IntPtr)(fix_buffer + front_temp);
            }
        }

        unsafe public IntPtr M_GetRearPtr()
        {
            Int32 rear_temp = m_rear + 1;
            if (rear_temp == (Int32)E_Initial_Value.buffer_size)
                rear_temp = 0;

            fixed (Byte* fix_buffer = m_buffer)
            {
                return (IntPtr)(fix_buffer + rear_temp);
            }
        }
    }
}
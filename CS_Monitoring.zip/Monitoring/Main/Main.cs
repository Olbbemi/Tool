﻿using System;
using System.Windows.Forms;

using Monitoring;

namespace Main
{
    class C_Main
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            C_Monitor monitor = new C_Monitor();
            monitor.Size = new System.Drawing.Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height / 2 + 150);

            Application.Run(monitor);
        }
    }
}